import os
import asyncio
import unittest
from database.db import (
    init_db,
    add_or_update_user,
    create_payment,
    update_payment_status,
    grant_subscription,
    get_bot_stats,
    get_pending_payments,
    get_latest_approved_payments,
    get_latest_rejected_payments
)
from keyboards.inline import (
    get_admin_review_keyboard,
    get_admin_rejection_reasons_keyboard
)


class TestPhase5ProductionFeatures(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        self.test_db = "test_phase5.db"
        if os.path.exists(self.test_db):
            os.remove(self.test_db)
        await init_db(self.test_db)

    async def asyncTearDown(self):
        if os.path.exists(self.test_db):
            os.remove(self.test_db)

    async def test_admin_rejection_reasons_keyboard(self):
        kb = get_admin_rejection_reasons_keyboard("PAY-2026-TEST5")
        self.assertIsNotNone(kb)
        callbacks = [btn.callback_data for row in kb.inline_keyboard for btn in row]
        self.assertIn("reject_reason:PAY-2026-TEST5:Wrong Amount", callbacks)
        self.assertIn("reject_reason:PAY-2026-TEST5:Screenshot Not Clear", callbacks)
        self.assertIn("reject_reason:PAY-2026-TEST5:Payment Not Found", callbacks)
        self.assertIn("reject_reason:PAY-2026-TEST5:Other", callbacks)
        self.assertIn("admin_cancel_reject:PAY-2026-TEST5", callbacks)

    async def test_bot_stats_query(self):
        await add_or_update_user(1001, "user1", "User One", self.test_db)
        await add_or_update_user(1002, "user2", "User Two", self.test_db)

        # Create 1 approved, 1 rejected, 1 pending
        await create_payment("PAY-1", 1001, 1, "KBZPay", "file1", self.test_db)
        await update_payment_status("PAY-1", "APPROVED", 999, db_file=self.test_db)

        await create_payment("PAY-2", 1002, 2, "WavePay", "file2", self.test_db)
        await update_payment_status("PAY-2", "REJECTED", 999, rejection_reason="Screenshot Not Clear", db_file=self.test_db)

        await create_payment("PAY-3", 1001, 3, "KBZPay", "file3", self.test_db)

        stats = await get_bot_stats(self.test_db)
        self.assertEqual(stats["total_users"], 2)
        self.assertEqual(stats["total_payments"], 3)
        self.assertEqual(stats["pending_payments"], 1)
        self.assertEqual(stats["approved_payments"], 1)
        self.assertEqual(stats["rejected_payments"], 1)

    async def test_pending_approved_rejected_queries(self):
        await add_or_update_user(2001, "customer", "Customer", self.test_db)

        await create_payment("PAY-P1", 2001, 1, "KBZPay", "f1", self.test_db)
        
        pending = await get_pending_payments(db_file=self.test_db)
        self.assertEqual(len(pending), 1)
        self.assertEqual(pending[0]["payment_id"], "PAY-P1")

        # Approve PAY-P1
        await update_payment_status("PAY-P1", "APPROVED", 999, db_file=self.test_db)

        approved = await get_latest_approved_payments(db_file=self.test_db)
        self.assertEqual(len(approved), 1)
        self.assertEqual(approved[0]["payment_id"], "PAY-P1")

        # Create & reject PAY-P2 with reason
        await create_payment("PAY-P2", 2001, 2, "WavePay", "f2", self.test_db)
        await update_payment_status("PAY-P2", "REJECTED", 999, rejection_reason="Wrong Amount", db_file=self.test_db)

        rejected = await get_latest_rejected_payments(db_file=self.test_db)
        self.assertEqual(len(rejected), 1)
        self.assertEqual(rejected[0]["rejection_reason"], "Wrong Amount")


if __name__ == "__main__":
    unittest.main()
