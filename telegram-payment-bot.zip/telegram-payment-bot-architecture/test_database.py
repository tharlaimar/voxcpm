import asyncio
import os
import sys
from database.db import (
    init_db,
    add_or_update_user,
    get_user,
    get_subscription_plans,
    create_payment,
    get_payment_by_id,
    update_payment_status,
    grant_subscription,
    get_active_user_subscription
)

TEST_DB = "test_payment_bot.db"


async def run_tests():
    print("=" * 65)
    print("  RUNNING STUDIO99 PRODUCTS AUTOMATED TEST SUITE (SQLITE & CONFIG)")
    print("=" * 65)
    
    # Ensure clean database test file
    if os.path.exists(TEST_DB):
        os.remove(TEST_DB)
        
    print("\n[TEST 1] Initializing SQLite tables & seeding Studio99 products...")
    await init_db(TEST_DB)
    plans = await get_subscription_plans(db_file=TEST_DB)
    assert len(plans) == 6, f"Expected 6 seeded products, got {len(plans)}"
    print(f"  -> PASS: {len(plans)} Studio99 products successfully seeded:")
    for p in plans:
        print(f"       • Product #{p['id']}: {p['name']} | Type: {p.get('product_type')} | Price: {p['price_mmk']:,} MMK")
        
    print("\n[TEST 2] Registering Test User...")
    test_user_id = 99887766
    await add_or_update_user(test_user_id, "test_username", "Aung Aung", db_file=TEST_DB)
    user = await get_user(test_user_id, db_file=TEST_DB)
    assert user is not None and user["full_name"] == "Aung Aung", "User registration failed!"
    print(f"  -> PASS: Registered User '{user['full_name']}' (@{user['username']}) [ID: {user['user_id']}]")
    
    print("\n[TEST 3] Creating Pending Payment Entry for Credit Package...")
    pay_id = "PAY-2026-TEST01"
    # Plan #1 is 10 Credits
    payment = await create_payment(pay_id, test_user_id, plan_id=1, payment_method="KBZPay", screenshot_file_id="file_id_xyz_123", db_file=TEST_DB)
    assert payment["status"] == "PENDING", "Payment initial status must be PENDING"
    print(f"  -> PASS: Created Payment ID '{payment['payment_id']}' (Method: {payment['payment_method']}, Status: {payment['status']})")
    
    print("\n[TEST 4] Admin Approval & Granting AI Credits...")
    updated_pay = await update_payment_status(pay_id, "APPROVED", reviewed_by=123456789, db_file=TEST_DB)
    assert updated_pay["status"] == "APPROVED", "Payment approval failed!"
    
    grant_res = await grant_subscription(test_user_id, plan_id=1, db_file=TEST_DB)
    assert grant_res["product_type"] == "credits" and grant_res["credit_amount"] == 10, "Credits grant failed!"
    
    user_after = await get_user(test_user_id, db_file=TEST_DB)
    assert user_after["credits"] == 10, f"Expected 10 credits, got {user_after['credits']}"
    print(f"  -> PASS: Granted 10 AI Credits to user balance (Current total: {user_after['credits']})")
    
    print("\n[TEST 5] Granting Voice Clone VIP Subscription...")
    # Plan #4 is Voice Clone VIP - 1 Day
    vip_res = await grant_subscription(test_user_id, plan_id=4, duration_days=1, db_file=TEST_DB)
    assert vip_res["product_type"] == "vip", "VIP subscription grant failed!"
    
    active_sub = await get_active_user_subscription(test_user_id, db_file=TEST_DB)
    assert active_sub is not None, "Active subscription search failed!"
    print(f"  -> PASS: Verified Active VIP Subscription Plan: '{active_sub['plan_name']}'")
    
    # Cleanup test db
    if os.path.exists(TEST_DB):
        os.remove(TEST_DB)
        
    print("\n" + "=" * 65)
    print("  ALL STUDIO99 PRODUCTS TESTS PASSED WITH 100% SUCCESS! 🚀")
    print("=" * 65)



if __name__ == "__main__":
    asyncio.run(run_tests())
