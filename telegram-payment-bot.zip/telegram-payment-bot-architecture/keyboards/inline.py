from typing import List, Dict, Any
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import settings


def get_categories_keyboard() -> InlineKeyboardMarkup:
    """Generate inline keyboard for home screen product categories."""
    builder = InlineKeyboardBuilder()
    builder.button(text="🎟 AI Credits", callback_data="category:credits")
    builder.button(text="🎙 Voice Clone VIP", callback_data="category:vip")
    if settings.SUPPORT_ADMIN_URL:
        builder.button(text="📞 Contact Admin", url=settings.SUPPORT_ADMIN_URL)
    builder.adjust(1)
    return builder.as_markup()


def get_credits_keyboard(plans: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
    """Generate inline keyboard for AI Credit packages."""
    builder = InlineKeyboardBuilder()
    credits_plans = [p for p in plans if p.get('product_type') == 'credits']
    
    for plan in credits_plans:
        btn_text = f"🎟 {plan['name']} — {plan['price_mmk']:,} MMK"
        builder.button(
            text=btn_text,
            callback_data=f"select_plan:{plan['id']}"
        )
    
    builder.button(text="🔙 Back", callback_data="show_categories")
    if settings.SUPPORT_ADMIN_URL:
        builder.button(text="📞 Contact Admin", url=settings.SUPPORT_ADMIN_URL)
    builder.adjust(1)
    return builder.as_markup()


def get_vip_keyboard(plans: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
    """Generate inline keyboard for Voice Clone VIP plans."""
    builder = InlineKeyboardBuilder()
    vip_plans = [p for p in plans if p.get('product_type') == 'vip']
    
    for plan in vip_plans:
        btn_text = f"🎙 {plan['name']} — {plan['price_mmk']:,} MMK"
        builder.button(
            text=btn_text,
            callback_data=f"select_plan:{plan['id']}"
        )
    
    builder.button(text="🔙 Back", callback_data="show_categories")
    if settings.SUPPORT_ADMIN_URL:
        builder.button(text="📞 Contact Admin", url=settings.SUPPORT_ADMIN_URL)
    builder.adjust(1)
    return builder.as_markup()


def get_plans_keyboard(plans: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
    """Fallback inline keyboard for available Studio99 products."""
    return get_categories_keyboard()


def get_payment_methods_keyboard(plan_id: int) -> InlineKeyboardMarkup:
    """Generate inline keyboard for payment method selection."""
    builder = InlineKeyboardBuilder()
    
    builder.button(text="🔵 KBZPay", callback_data=f"method:KBZPay:{plan_id}")
    builder.button(text="🟡 WavePay", callback_data=f"method:WavePay:{plan_id}")
    builder.button(text="🔙 Back to Categories", callback_data="show_categories")
    builder.button(text="❌ Cancel Payment", callback_data="cancel_payment")
    
    builder.adjust(2, 1, 1)
    return builder.as_markup()


def get_payment_details_keyboard(payment_method: str, plan_id: int) -> InlineKeyboardMarkup:
    """Generate inline keyboard for payment page with copy, upload, change method, contact and cancel buttons."""
    builder = InlineKeyboardBuilder()
    
    builder.button(text="📋 Copy Number", callback_data=f"copy_no:{payment_method}")
    builder.button(text="📤 Upload Screenshot", callback_data="upload_prompt")
    builder.button(text="🔄 Change Payment Method", callback_data=f"select_plan:{plan_id}")
    if settings.SUPPORT_ADMIN_URL:
        builder.button(text="📞 Contact Admin", url=settings.SUPPORT_ADMIN_URL)
    builder.button(text="❌ Cancel", callback_data="cancel_payment")
    
    if settings.SUPPORT_ADMIN_URL:
        builder.adjust(2, 1, 2)
    else:
        builder.adjust(2, 1, 1)
    return builder.as_markup()


def get_cancel_keyboard() -> InlineKeyboardMarkup:
    """Inline keyboard with Cancel Payment button during screenshot upload."""
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Cancel Payment", callback_data="cancel_payment")
    if settings.SUPPORT_ADMIN_URL:
        builder.button(text="📞 Contact Admin", url=settings.SUPPORT_ADMIN_URL)
    builder.adjust(1)
    return builder.as_markup()


def get_contact_admin_keyboard() -> InlineKeyboardMarkup:
    """Contact Admin keyboard."""
    builder = InlineKeyboardBuilder()
    if settings.SUPPORT_ADMIN_URL:
        builder.button(text="📞 Contact Admin", url=settings.SUPPORT_ADMIN_URL)
    builder.button(text="🔙 Back to Categories", callback_data="show_categories")
    builder.adjust(1)
    return builder.as_markup()



def get_admin_review_keyboard(payment_id: str) -> InlineKeyboardMarkup:
    """Generate inline keyboard with Approve and Reject buttons for Admin Group (Req 1)."""
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Approve", callback_data=f"admin_approve:{payment_id}")
    builder.button(text="❌ Reject", callback_data=f"admin_reject:{payment_id}")
    builder.adjust(2)
    return builder.as_markup()


def get_admin_rejection_reasons_keyboard(payment_id: str) -> InlineKeyboardMarkup:
    """Generate inline keyboard for selecting rejection reason (Req 5)."""
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Wrong Amount", callback_data=f"reject_reason:{payment_id}:Wrong Amount")
    builder.button(text="📷 Screenshot Not Clear", callback_data=f"reject_reason:{payment_id}:Screenshot Not Clear")
    builder.button(text="💸 Payment Not Found", callback_data=f"reject_reason:{payment_id}:Payment Not Found")
    builder.button(text="✍️ Other", callback_data=f"reject_reason:{payment_id}:Other")
    builder.button(text="🔙 Cancel", callback_data=f"admin_cancel_reject:{payment_id}")
    builder.adjust(2, 2, 1)
    return builder.as_markup()


