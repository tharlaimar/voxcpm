# 🤖 Telegram Payment Bot (Studio99 VIP)

An asynchronous Telegram Payment Bot built with **aiogram 3.x** and **SQLite3**, designed for automated VIP subscription plans, manual payment verification via KBZPay and WavePay, and admin group review workflows.

---

## 🌟 Key Features

- **Asynchronous Architecture:** Built with `aiogram 3.x` and `asyncio.to_thread` for non-blocking SQLite database execution.
- **SQLite Database Layer:** Automatic schema creation, indexed foreign keys, and seed subscription plans (1 Month, 3 Months, 1 Year).
- **Interactive Inline Keyboards:** Copy payment numbers directly, upload screenshots, change payment methods, contact support admins, or cancel transactions.
- **FSM Payment Workflow:** State-machine guided flow requiring payment receipt photo uploads (filters out text/stickers/documents).
- **Duplicate Prevention:** Prevents users from submitting duplicate payments while a pending submission is under review.
- **Admin Review Group:** Direct forward to Admin Group with `Approve` and `Reject` inline buttons.
- **Custom Rejection Reasons:** Select reasons (Wrong Amount, Screenshot Not Clear, Payment Not Found, Other) with instant user feedback.
- **Admin Commands:** `/stats`, `/pending`, `/approved`, `/rejected`.
- **Dual Logging System:** Console logging and persistence in `logs/bot.log`.
- **Production Ready Deployment:** Dockerfile, Procfile, Systemd, and cross-platform compatibility (Windows, VPS, Railway, Render).

---

## 🚀 Deployment Instructions

### 1. Windows / Local Machine
```bash
# Clone repository and enter directory
cd telegram-payment-bot

# Create python virtual environment
python -m venv venv
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy configuration
cp .env.example .env

# Run bot
python main.py
```

### 2. Ubuntu VPS (Systemd Service)
```bash
# Install python3-venv
sudo apt update && sudo apt install -y python3-pip python3-venv git

# Clone repo & setup venv
git clone <your-repo-url>
cd telegram-payment-bot
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Setup systemd service
sudo nano /etc/systemd/system/payment-bot.service
```

Example `payment-bot.service`:
```ini
[Unit]
Description=Telegram Payment Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/telegram-payment-bot
ExecStart=/home/ubuntu/telegram-payment-bot/venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
# Enable & start service
sudo systemctl daemon-reload
sudo systemctl enable payment-bot
sudo systemctl start payment-bot
sudo systemctl status payment-bot
```

### 3. Docker Container
```bash
# Build image
docker build -t telegram-payment-bot .

# Run container with environment file
docker run -d --name payment_bot --env-file .env telegram-payment-bot
```

### 4. Railway & Render Deployment
- **Railway:** Connect GitHub repo. Railway auto-detects `Procfile` or `Dockerfile`. Set environment variables in Railway dashboard.
- **Render:** Create a **Background Worker** service. Connect repo, set build command `pip install -r requirements.txt` and start command `python main.py`.
