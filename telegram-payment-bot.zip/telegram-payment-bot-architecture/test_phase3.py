import asyncio
import os
import unittest
from datetime import datetime
from database.db import (
    init_db,
    add_or_update_user,
    get_user,
    get_subscription_plans,
    get_plan_by_id,
    create_payment,
    get_pending_payment_by_user,
    get_payment_by_id,
    DB_PATH
)
from keyboards.inline import (
    get_plans_keyboard,
    get_payment_methods_keyboard,
    get_cancel_keyboard
)


class TestPhase3UserWorkflow(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        self.test_db = "test_phase3.db"
        if os.path.exists(self.test_db):
            os.remove(self.test_db)
        await init_db(self.test_db)

    async def asyncTearDown(self):
        if os.path.exists(self.test_db):
            os.remove(self.test_db)

    async def test_keyboards_generation(self):
        plans = await get_subscription_plans(self.test_db)
        plans_kb = get_plans_keyboard(plans)
        self.assertIsNotNone(plans_kb)
        # Categories: AI Credits, Voice Clone VIP (+ Contact Admin if SUPPORT_ADMIN_URL configured)
        expected_btn_count = 3 if settings.SUPPORT_ADMIN_URL else 2
        self.assertEqual(len(plans_kb.inline_keyboard), expected_btn_count)

        methods_kb = get_payment_methods_keyboard(plan_id=1)
        self.assertIsNotNone(methods_kb)

        cancel_kb = get_cancel_keyboard()
        self.assertIsNotNone(cancel_kb)

    async def test_user_registration_and_plan_fetching(self):
        user_id = 987654321
        user = await add_or_update_user(user_id, "test_user", "Test User", self.test_db)
        self.assertEqual(user["user_id"], user_id)

        plans = await get_subscription_plans(self.test_db)
        self.assertGreater(len(plans), 0)

        selected_plan = await get_plan_by_id(plans[0]["id"], self.test_db)
        self.assertEqual(selected_plan["id"], plans[0]["id"])

    async def test_pending_payment_creation_and_duplicate_prevention(self):
        user_id = 11223344
        await add_or_update_user(user_id, "payer", "Payer One", self.test_db)

        # No pending payment initially
        pending = await get_pending_payment_by_user(user_id, self.test_db)
        self.assertIsNone(pending)

        # Create payment
        payment_id = "PAY-20260727-9999"
        created = await create_payment(
            payment_id=payment_id,
            user_id=user_id,
            plan_id=1,
            payment_method="KBZPay",
            screenshot_file_id="AgACAgIAAxkBAA...",
            db_file=self.test_db
        )
        self.assertEqual(created["status"], "PENDING")

        # Now get_pending_payment_by_user should return this payment
        pending = await get_pending_payment_by_user(user_id, self.test_db)
        self.assertIsNotNone(pending)
        self.assertEqual(pending["payment_id"], payment_id)
        self.assertEqual(pending["user_id"], user_id)
        self.assertEqual(pending["payment_method"], "KBZPay")


if __name__ == "__main__":
    unittest.main()
