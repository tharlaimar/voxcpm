import random
import logging
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from config import settings
from states.payment import PaymentState
from database.db import (
    add_or_update_user,
    get_user,
    get_user_credits,
    get_subscription_plans,
    get_plan_by_id,
    get_pending_payment_by_user,
    get_active_user_subscription,
    create_payment,
    set_admin_message_id
)
from keyboards.inline import (
    get_categories_keyboard,
    get_credits_keyboard,
    get_vip_keyboard,
    get_plans_keyboard,
    get_payment_methods_keyboard,
    get_payment_details_keyboard,
    get_cancel_keyboard,
    get_contact_admin_keyboard,
    get_admin_review_keyboard
)

logger = logging.getLogger(__name__)
user_router = Router(name="user_router")


FOOTER = "\n\n<i>Powered by Studio99</i>"


@user_router.message(CommandStart())
async def command_start_handler(message: Message, state: FSMContext) -> None:
    """Handle /start command - Register user profile and show Studio99 category store."""
    try:
        await state.clear()
        
        user_id = message.from_user.id
        username = message.from_user.username
        full_name = message.from_user.full_name or "User"
        first_name = message.from_user.first_name or full_name
        
        logger.info(f"User started bot: ID={user_id}, Username=@{username or 'None'}, Name={full_name}")
        
        # Save user into SQLite database
        await add_or_update_user(user_id, username, full_name)
        
        welcome_text = (
            f"🤖 <b>Studio99 Store</b>\n\n"
            f"👋 မင်္ဂလာပါ {first_name}\n\n"
            f"Studio99 မှ ကြိုဆိုပါတယ်။\n\n"
            f"အောက်တွင် ဝယ်ယူလိုသည့် Product ကို ရွေးချယ်ပါ။\n\n"
            f"📌 <b>သတိပြုရန်</b>\n\n"
            f"• ဝယ်ယူလိုသည့် Product ကို အရင်ရွေးချယ်ပါ။\n"
            f"• ငွေလွှဲသည့် ပမာဏမှန်ကန်ကြောင်း သေချာစစ်ဆေးပါ။\n"
            f"• ငွေလွှဲပြီးပါက Screenshot ကို ရှင်းလင်းစွာ ပို့ပေးပါ။\n"
            f"• Payment စစ်ဆေးရန် မိနစ်အနည်းငယ် ကြာနိုင်ပါသည်။\n"
            f"• အခက်အခဲရှိပါက Contact Admin မှ တိုက်ရိုက်ဆက်သွယ်နိုင်ပါသည်။\n\n"
            f"━━━━━━━━━━━━━━\n\n"
            f"🎟 AI Credits\n"
            f"🎙 Voice Clone VIP\n\n"
            f"━━━━━━━━━━━━━━\n"
            f"Powered by Studio99"
        )

        keyboard = get_categories_keyboard()
        await message.answer(welcome_text, parse_mode="HTML", reply_markup=keyboard)
    except Exception as e:
        logger.error(f"Error handling /start command for user {message.from_user.id}: {e}")
        await message.answer("❌ An error occurred. Please try again." + FOOTER)


@user_router.message(Command("help"))
async def command_help_handler(message: Message) -> None:
    """Handle /help command providing instructions and usage guide."""
    is_admin = message.from_user.id in settings.admin_ids
    
    help_text = (
        "💡 <b>Studio99 Bot Help & Guide</b>\n\n"
        "<b>Available Commands:</b>\n"
        "• /start — View Studio99 products & begin purchase\n"
        "• /status — Check AI credits, VIP status & payments\n"
        "• /help — Show this guidance menu\n\n"
        "<b>How to Purchase:</b>\n"
        "1️⃣ Tap /start and select your desired product\n"
        "2️⃣ Choose payment method (KBZPay or WavePay)\n"
        "3️⃣ Transfer exact amount to the account\n"
        "4️⃣ Send payment screenshot photo into chat\n"
        "5️⃣ Admin team will verify and activate your order!"
    )
    
    if is_admin:
        help_text += (
            "\n\n👑 <b>Admin Commands:</b>\n"
            "• /stats — Detailed overall bot statistics\n"
            "• /pending — List pending payments awaiting review\n"
            "• /approved — List recent approved payments\n"
            "• /rejected — List recent rejected payments"
        )
        
    help_text += FOOTER
    await message.answer(help_text, parse_mode="HTML")


@user_router.message(Command("status"))
async def command_status_handler(message: Message) -> None:
    """Handle /status command showing current AI credits, active VIP status, or pending payments."""
    try:
        user_id = message.from_user.id
        full_name = message.from_user.full_name or "User"
        
        active_sub = await get_active_user_subscription(user_id)
        user_credits = await get_user_credits(user_id)
        pending_pay = await get_pending_payment_by_user(user_id)
        
        status_text = f"👤 <b>Account Status for {full_name}</b>\n\n"
        status_text += f"🎟 <b>AI Credits Balance:</b> <code>{user_credits} Credits</code>\n\n"
        
        if active_sub:
            status_text += (
                f"🎙 <b>Voice Clone VIP:</b> <code>ACTIVE</code> ✅\n"
                f"• <b>Plan:</b> {active_sub['plan_name']}\n"
                f"• <b>Valid Until:</b> <code>{active_sub['expires_at'][:10]}</code>\n\n"
            )
        else:
            status_text += f"🎙 <b>Voice Clone VIP:</b> <code>INACTIVE</code>\n\n"

        if pending_pay:
            status_text += (
                f"⏳ <b>Pending Payment Submission:</b>\n"
                f"• <b>Payment ID:</b> <code>{pending_pay['payment_id']}</code>\n"
                f"• <b>Product:</b> {pending_pay['plan_name']}\n"
                f"• <b>Method:</b> {pending_pay['payment_method']}\n"
                f"• <b>Status:</b> <code>UNDER ADMIN REVIEW</code> ⏳"
            )
            
        status_text += FOOTER
        await message.answer(status_text, parse_mode="HTML")
    except Exception as e:
        logger.error(f"Error executing /status command for user {message.from_user.id}: {e}")
        await message.answer("❌ An error occurred while checking status." + FOOTER)


@user_router.callback_query(F.data == "category:credits")
async def category_credits_handler(callback: CallbackQuery) -> None:
    """Show AI Credits packages menu."""
    plans = await get_subscription_plans()
    keyboard = get_credits_keyboard(plans)
    
    text = (
        "🎟 <b>AI Credits</b>\n\n"
        "Choose a package:\n\n"
        "• 10 Credits — 1,000 MMK\n"
        "• 30 Credits — 3,000 MMK\n"
        "• 50 Credits — 5,000 MMK"
    )
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


@user_router.callback_query(F.data == "category:vip")
async def category_vip_handler(callback: CallbackQuery) -> None:
    """Show Voice Clone VIP plans menu."""
    plans = await get_subscription_plans()
    keyboard = get_vip_keyboard(plans)
    
    text = (
        "🎙 <b>Voice Clone VIP</b>\n\n"
        "Choose a plan:\n\n"
        "• 1 Day — 500 MMK\n"
        "• 7 Days — 2,500 MMK\n"
        "• 30 Days — 10,000 MMK"
    )
    await callback.message.edit_text(text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


@user_router.callback_query(F.data.in_({"show_categories", "show_plans"}))
async def show_categories_callback(callback: CallbackQuery, state: FSMContext) -> None:
    """Return to main product categories home screen."""
    await state.clear()
    first_name = callback.from_user.first_name or callback.from_user.full_name or "User"
    welcome_text = (
        f"🤖 <b>Studio99 Store</b>\n\n"
        f"👋 မင်္ဂလာပါ {first_name}\n\n"
        f"Studio99 မှ ကြိုဆိုပါတယ်။\n\n"
        f"အောက်တွင် ဝယ်ယူလိုသည့် Product ကို ရွေးချယ်ပါ။\n\n"
        f"📌 <b>သတိပြုရန်</b>\n\n"
        f"• ဝယ်ယူလိုသည့် Product ကို အရင်ရွေးချယ်ပါ။\n"
        f"• ငွေလွှဲသည့် ပမာဏမှန်ကန်ကြောင်း သေချာစစ်ဆေးပါ။\n"
        f"• ငွေလွှဲပြီးပါက Screenshot ကို ရှင်းလင်းစွာ ပို့ပေးပါ။\n"
        f"• Payment စစ်ဆေးရန် မိနစ်အနည်းငယ် ကြာနိုင်ပါသည်။\n"
        f"• အခက်အခဲရှိပါက Contact Admin မှ တိုက်ရိုက်ဆက်သွယ်နိုင်ပါသည်။\n\n"
        f"━━━━━━━━━━━━━━\n\n"
        f"🎟 AI Credits\n"
        f"🎙 Voice Clone VIP\n\n"
        f"━━━━━━━━━━━━━━\n"
        f"Powered by Studio99"
    )
    keyboard = get_categories_keyboard()
    await callback.message.edit_text(welcome_text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


@user_router.callback_query(F.data.startswith("select_plan:"))
async def select_plan_handler(callback: CallbackQuery, state: FSMContext) -> None:
    """Handle product selection."""
    user_id = callback.from_user.id
    
    # Check if user already has a pending payment
    pending_pay = await get_pending_payment_by_user(user_id)
    if pending_pay:
        await callback.answer(
            f"⚠️ You already have a pending payment under review ({pending_pay['payment_id']})!",
            show_alert=True
        )
        return

    plan_id = int(callback.data.split(":")[1])
    plan = await get_plan_by_id(plan_id)
    
    if not plan:
        await callback.answer("❌ Selected product was not found.", show_alert=True)
        return

    await state.update_data(plan_id=plan_id)
    await state.set_state(PaymentState.selecting_method)
    
    category_icon = "🎟" if plan.get("product_type") == "credits" else "🎙"
    product_desc = plan.get("description", "")

    method_text = (
        f"{category_icon} <b>Selected Product: {plan['name']}</b>\n"
        f"💰 <b>Price:</b> {plan['price_mmk']:,} MMK\n"
        f"📝 <i>{product_desc}</i>\n\n"
        f"💳 <b>Select Payment Method:</b>"
    )
    keyboard = get_payment_methods_keyboard(plan_id)
    
    await callback.message.edit_text(method_text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()



@user_router.callback_query(F.data.startswith("method:"))
async def select_payment_method_handler(callback: CallbackQuery, state: FSMContext) -> None:
    """Show payment account details and instructions based on product type."""
    parts = callback.data.split(":")
    payment_method = parts[1]  # 'KBZPay' or 'WavePay'
    plan_id = int(parts[2])
    
    plan = await get_plan_by_id(plan_id)
    if not plan:
        await callback.answer("❌ ရွေးချယ်ထားသော Product ကို ရှာမတွေ့ပါ။", show_alert=True)
        return

    if payment_method == "KBZPay":
        acc_no = settings.KBZPAY_NO
        acc_name = settings.KBZPAY_NAME
        title = "💙 KBZPay"
    else:
        acc_no = settings.WAVEPAY_NO
        acc_name = settings.WAVEPAY_NAME
        title = "🟡 WavePay"

    await state.update_data(plan_id=plan_id, payment_method=payment_method)
    await state.set_state(PaymentState.waiting_for_screenshot)

    product_type = plan.get("product_type", "vip")

    if product_type == "credits":
        # For AI Credits: Request screenshot and Studio99 Email/ID together
        account_text = (
            f"{title}\n\n"
            f"<b>Account Name:</b> {acc_name}\n"
            f"<b>Account Number:</b> <code>{acc_no}</code>\n\n"
            f"ဝယ်ယူမည့် Product: <b>{plan['name']} ({plan['price_mmk']:,} MMK)</b>\n\n"
            f"📷 <b>ငွေလွှဲ Screenshot ကို ပို့ပေးပါ။</b>\n\n"
            f"Screenshot နှင့်အတူ Studio99 Email (သို့) User ID ကို Caption တွင်ဖြစ်စေ၊ Message တစ်စောင်အဖြစ်ဖြစ်စေ တစ်ခါတည်း ပို့ပေးပါ။\n\n"
            f"Example:\n\n"
            f"📧 user@gmail.com\n\n"
            f"or\n\n"
            f"🆔 user_12345"
        )
    else:
        # For Voice Clone VIP: Directly ask for screenshot
        account_text = (
            f"{title}\n\n"
            f"<b>Account Name:</b> {acc_name}\n"
            f"<b>Account Number:</b> <code>{acc_no}</code>\n\n"
            f"ဝယ်ယူမည့် Product: <b>{plan['name']} ({plan['price_mmk']:,} MMK)</b>\n\n"
            f"📸 <b>ငွေ {plan['price_mmk']:,} MMK လွှဲပြီးပါက ငွေလွှဲ Screenshot ဓာတ်ပုံကို ဤနေရာတွင် ပို့ပေးပါ။</b>"
        )

    keyboard = get_payment_details_keyboard(payment_method, plan_id)
    await callback.message.edit_text(account_text, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


@user_router.message(PaymentState.waiting_for_account, F.text)
async def receive_studio99_account(message: Message, state: FSMContext) -> None:
    """Receive Studio99 Email/ID following photo upload for AI Credits."""
    account_input = message.text.strip()
    if not account_input:
        await message.answer("❌ ကျေးဇူးပြု၍ သင်၏ Studio99 Email သို့မဟုတ် User ID ကို ရိုက်ထည့်ပေးပါ။" + FOOTER, parse_mode="HTML")
        return

    data = await state.get_data()
    plan_id = data.get("plan_id")
    payment_method = data.get("payment_method", "KBZPay")
    temp_photo_id = data.get("temp_photo_id")

    plan = await get_plan_by_id(plan_id)
    if not plan:
        await message.answer("❌ ရွေးချယ်ထားသော Product ကို ရှာမတွေ့ပါ။ ကျေးဇူးပြု၍ /start ဖြင့် ပြန်လည်စတင်ပါ။" + FOOTER, parse_mode="HTML")
        await state.clear()
        return

    if temp_photo_id:
        await _submit_payment_and_notify(
            message=message,
            state=state,
            plan=plan,
            payment_method=payment_method,
            screenshot_file_id=temp_photo_id,
            studio99_account=account_input
        )
    else:
        await state.update_data(studio99_account=account_input)
        await state.set_state(PaymentState.waiting_for_screenshot)
        await message.answer(
            f"✅ <b>Studio99 Account:</b> <code>{account_input}</code>\n\n"
            f"📸 <b>ကျေးဇူးပြု၍ သင်၏ ငွေလွှဲ Screenshot ဓာတ်ပုံကို ပို့ပေးပါ။</b>" + FOOTER,
            parse_mode="HTML"
        )


@user_router.message(PaymentState.waiting_for_account)
async def invalid_account_handler(message: Message) -> None:
    """Handle non-text input when waiting for Studio99 Email / User ID."""
    await message.answer("❌ ကျေးဇူးပြု၍ သင်၏ Studio99 Email သို့မဟုတ် User ID ကို စာသားဖြင့် ရိုက်ထည့်ပေးပါ။" + FOOTER, parse_mode="HTML")


@user_router.callback_query(F.data.startswith("copy_no:"))
async def copy_number_handler(callback: CallbackQuery) -> None:
    """Handle '📋 Copy Number' button click (Req 10)."""
    method = callback.data.split(":")[1]
    acc_no = settings.KBZPAY_NO if method == "KBZPay" else settings.WAVEPAY_NO
    
    response_text = (
        "📋 <b>Copy Account Number</b>\n\n"
        "ကူးယူရန် အောက်ပါနံပါတ်ကို ဖိထားပါ:\n\n"
        f"<code>{acc_no}</code>" + FOOTER
    )
    await callback.message.answer(response_text, parse_mode="HTML")
    await callback.answer()


@user_router.callback_query(F.data == "upload_prompt")
async def upload_prompt_handler(callback: CallbackQuery) -> None:
    """Prompt user to upload screenshot."""
    await callback.message.answer(
        "📸 <b>ကျေးဇူးပြု၍ သင်၏ ငွေလွှဲ Screenshot ဓာတ်ပုံကို ဤနေရာတွင် ပို့ပေးပါ။</b>" + FOOTER,
        parse_mode="HTML"
    )
    await callback.answer()


@user_router.callback_query(F.data == "cancel_payment")
async def cancel_payment_handler(callback: CallbackQuery, state: FSMContext) -> None:
    """Cancel payment flow and reset state."""
    await state.clear()
    keyboard = get_contact_admin_keyboard()
    await callback.message.edit_text(
        "❌ <b>ငွေပေးချေမှု ပယ်ဖျက်လိုက်ပါပြီ။</b>\n\nProduct များ ပြန်လည်ကြည့်ရှုရန် /start ကို နှိပ်ပါ သို့မဟုတ် Admin ကို ဆက်သွယ်ပါ။" + FOOTER,
        parse_mode="HTML",
        reply_markup=keyboard
    )
    await callback.answer("ငွေပေးချေမှု ပယ်ဖျက်လိုက်ပါသည်။")


@user_router.callback_query(F.data == "contact_admin")
async def contact_admin_handler(callback: CallbackQuery) -> None:
    """Show contact admin information."""
    admin_info = (
        "💬 <b>အကူအညီလိုအပ်ပါသလား?</b>\n\n"
        "ငွေပေးချေမှု၊ AI Credits သို့မဟုတ် Voice Clone VIP နှင့် ပတ်သက်ပြီး အခက်အခဲရှိပါက အောက်ပါခလုတ်မှ Admin ကို တိုက်ရိုက်ဆက်သွယ်နိုင်ပါသည်။\n\n"
        "━━━━━━━━━━━━━━\n"
        "Powered by Studio99"
    )
    keyboard = get_contact_admin_keyboard()
    try:
        await callback.message.edit_text(admin_info, parse_mode="HTML", reply_markup=keyboard)
    except Exception:
        await callback.message.answer(admin_info, parse_mode="HTML", reply_markup=keyboard)
    await callback.answer()


async def _submit_payment_and_notify(
    message: Message,
    state: FSMContext,
    plan: dict,
    payment_method: str,
    screenshot_file_id: str,
    studio99_account: Optional[str]
) -> None:
    """Create payment in DB and send notifications to user and admin group."""
    user_id = message.from_user.id
    username = message.from_user.username
    full_name = message.from_user.full_name or "User"

    # Prevent duplicate pending payments
    pending_pay = await get_pending_payment_by_user(user_id)
    if pending_pay:
        await message.answer(
            f"⚠️ <b>စစ်ဆေးဆဲ ငွေလွှဲမှု ရှိနေပါသည်။</b>\n\n"
            f"သင်၏ Payment ID <code>{pending_pay['payment_id']}</code> အား Admin မှ စစ်ဆေးနေဆဲ ဖြစ်ပါသည်။\n\n"
            f"ခေတ္တ စောင့်ဆိုင်းပေးပါရန်။" + FOOTER,
            parse_mode="HTML"
        )
        await state.clear()
        return

    pay_date = datetime.utcnow().strftime("%Y%m%d")
    random_code = random.randint(1000, 9999)
    payment_id = f"PAY-{pay_date}-{random_code}"

    payment_record = await create_payment(
        payment_id=payment_id,
        user_id=user_id,
        plan_id=plan["id"],
        payment_method=payment_method,
        screenshot_file_id=screenshot_file_id,
        studio99_account=studio99_account
    )

    logger.info(
        f"Payment submitted: ID={payment_id}, User={user_id} (@{username or 'None'}), "
        f"Plan={plan['name']}, Method={payment_method}, Studio99Account={studio99_account}"
    )

    product_type = plan.get("product_type", "vip")
    product_type_label = "🎟 AI Credits" if product_type == "credits" else "🎙 Voice Clone VIP"

    user_confirm_msg = (
        f"✅ <b>ငွေလွှဲ Screenshot ရရှိပါပြီ!</b>\n\n"
        f"• <b>Payment ID:</b> <code>{payment_id}</code>\n"
        f"• <b>Product:</b> {plan['name']}\n"
        f"• <b>Category:</b> {product_type_label}\n"
    )
    if studio99_account:
        user_confirm_msg += f"• <b>Studio99 Account:</b> <code>{studio99_account}</code>\n"

    user_confirm_msg += (
        f"• <b>ပမာဏ:</b> {plan['price_mmk']:,} MMK\n"
        f"• <b>Payment Method:</b> {payment_method}\n"
        f"• <b>Status:</b> <code>PENDING ADMIN REVIEW</code> ⏳\n\n"
        f"<i>Admin မှ စစ်ဆေးနေပါသည်။ စစ်ဆေးပြီးပါက အကြောင်းကြားပေးပါမည်။</i>" + FOOTER
    )
    await message.answer(user_confirm_msg, parse_mode="HTML")

    # Format admin group message according to workflow spec
    username_str = f"@{username}" if username else "N/A"
    submitted_time = datetime.utcnow().strftime("%Y-%m-%d %H:%M")

    if product_type == "credits":
        admin_caption = (
            f"🆕 <b>New Payment Submission (AI Credits)</b>\n\n"
            f"👤 <b>Telegram Name:</b> {full_name}\n"
            f"🏷 <b>Telegram Username:</b> {username_str}\n"
            f"🆔 <b>Telegram User ID:</b> <code>{user_id}</code>\n"
            f"📧 <b>Studio99 Email/User ID:</b> <code>{studio99_account or 'N/A'}</code>\n"
            f"📦 <b>Product:</b> {plan['name']}\n"
            f"💳 <b>Payment Method:</b> {payment_method}\n"
            f"🆔 <b>Payment ID:</b> <code>{payment_id}</code>\n"
            f"🕒 <b>Submitted:</b> {submitted_time}\n\n"
            f"📷 Payment Screenshot Attached"
        )
    else:
        admin_caption = (
            f"🆕 <b>New Payment Submission (Voice Clone VIP)</b>\n\n"
            f"👤 <b>Telegram Name:</b> {full_name}\n"
            f"🏷 <b>Telegram Username:</b> {username_str}\n"
            f"🆔 <b>Telegram User ID:</b> <code>{user_id}</code>\n"
            f"📦 <b>Product:</b> {plan['name']}\n"
            f"💳 <b>Payment Method:</b> {payment_method}\n"
            f"🆔 <b>Payment ID:</b> <code>{payment_id}</code>\n"
            f"🕒 <b>Submitted:</b> {submitted_time}\n\n"
            f"📷 Payment Screenshot Attached"
        )

    try:
        admin_msg = await message.bot.send_photo(
            chat_id=settings.ADMIN_GROUP_ID,
            photo=screenshot_file_id,
            caption=admin_caption,
            parse_mode="HTML",
            reply_markup=get_admin_review_keyboard(payment_id)
        )
        await set_admin_message_id(payment_id, admin_msg.message_id)
        logger.info(f"Successfully forwarded payment {payment_id} to admin group message_id {admin_msg.message_id}")
    except Exception as e:
        logger.error(f"Failed to send payment review to Admin Group ({settings.ADMIN_GROUP_ID}): {e}")

    await state.clear()


@user_router.message(PaymentState.waiting_for_screenshot, F.photo)
async def receive_payment_screenshot(message: Message, state: FSMContext) -> None:
    """Handle uploaded payment screenshot photo."""
    data = await state.get_data()
    plan_id = data.get("plan_id")
    payment_method = data.get("payment_method", "KBZPay")

    plan = await get_plan_by_id(plan_id)
    if not plan:
        await message.answer("❌ ရွေးချယ်ထားသော Product ကို ရှာမတွေ့ပါ။ /start ဖြင့် ပြန်လည်စတင်ပါ။" + FOOTER, parse_mode="HTML")
        await state.clear()
        return

    screenshot_file_id = message.photo[-1].file_id
    product_type = plan.get("product_type", "vip")

    if product_type == "credits":
        caption = (message.caption or "").strip()
        stored_account = data.get("studio99_account")
        studio99_account = caption or stored_account

        if studio99_account:
            await _submit_payment_and_notify(
                message=message,
                state=state,
                plan=plan,
                payment_method=payment_method,
                screenshot_file_id=screenshot_file_id,
                studio99_account=studio99_account
            )
        else:
            await state.update_data(temp_photo_id=screenshot_file_id)
            await state.set_state(PaymentState.waiting_for_account)
            await message.answer(
                "📧 <b>ကျေးဇူးပြု၍ သင်၏ Studio99 Email (သို့) User ID ကို စာသားဖြင့် ပို့ပေးပါ။</b>\n\n"
                "Example:\n"
                "📧 user@gmail.com\n\n"
                "or\n\n"
                "🆔 user_12345" + FOOTER,
                parse_mode="HTML"
            )
    else:
        await _submit_payment_and_notify(
            message=message,
            state=state,
            plan=plan,
            payment_method=payment_method,
            screenshot_file_id=screenshot_file_id,
            studio99_account=None
        )


@user_router.message(PaymentState.waiting_for_screenshot, F.text)
async def receive_text_when_waiting_screenshot(message: Message, state: FSMContext) -> None:
    """Handle text message when waiting for screenshot."""
    data = await state.get_data()
    plan_id = data.get("plan_id")
    plan = await get_plan_by_id(plan_id) if plan_id else None

    if plan and plan.get("product_type") == "credits":
        account_input = message.text.strip()
        await state.update_data(studio99_account=account_input)
        await message.answer(
            f"✅ <b>Studio99 Account:</b> <code>{account_input}</code>\n\n"
            f"📸 <b>ကျေးဇူးပြု၍ သင်၏ ငွေလွှဲ Screenshot ဓာတ်ပုံကို ပို့ပေးပါ။</b>" + FOOTER,
            parse_mode="HTML"
        )
    else:
        await message.answer("❌ <b>မမှန်ကန်ပါ:</b> ကျေးဇူးပြု၍ ငွေလွှဲ Screenshot ဓာတ်ပုံကို ပို့ပေးပါ။" + FOOTER, parse_mode="HTML")


@user_router.message(PaymentState.waiting_for_screenshot)
async def invalid_screenshot_handler(message: Message) -> None:
    """Handle non-photo / non-text input sent while waiting for screenshot."""
    await message.answer("❌ <b>မမှန်ကန်ပါ:</b> ကျေးဇူးပြု၍ ငွေလွှဲ Screenshot ဓာတ်ပုံကို ပို့ပေးပါ။" + FOOTER, parse_mode="HTML")

