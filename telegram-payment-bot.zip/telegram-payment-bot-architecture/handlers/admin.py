import logging
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery

from config import settings
from database.db import (
    get_payment_by_id,
    update_payment_status,
    grant_subscription,
    get_bot_stats,
    get_pending_payments,
    get_latest_approved_payments,
    get_latest_rejected_payments
)
from keyboards.inline import (
    get_admin_review_keyboard,
    get_admin_rejection_reasons_keyboard,
    get_contact_admin_keyboard
)

logger = logging.getLogger(__name__)
admin_router = Router(name="admin_router")

FOOTER = "\n\n<i>Powered by Studio99</i>"


def is_admin(user_id: int) -> bool:
    """Check if given Telegram user ID is an authorized admin."""
    return user_id in settings.admin_ids


# --- Admin Commands ---

@admin_router.message(Command("stats"))
async def command_stats_handler(message: Message) -> None:
    """Handle /stats command for admins (Req 1)."""
    if not is_admin(message.from_user.id):
        await message.answer("⚠️ Only authorized admins can view statistics.")
        return

    try:
        stats = await get_bot_stats()
        stats_text = (
            "📊 <b>Bot Statistics</b>\n\n"
            f"👥 <b>Total Users:</b> {stats['total_users']}\n"
            f"💳 <b>Total Payments:</b> {stats['total_payments']}\n"
            f"⏳ <b>Pending Payments:</b> {stats['pending_payments']}\n"
            f"✅ <b>Approved Payments:</b> {stats['approved_payments']}\n"
            f"❌ <b>Rejected Payments:</b> {stats['rejected_payments']}"
        )
        await message.answer(stats_text, parse_mode="HTML")
        logger.info(f"Admin {message.from_user.id} requested /stats")
    except Exception as e:
        logger.error(f"Error executing /stats command: {e}")
        await message.answer("❌ An error occurred while fetching statistics.")


@admin_router.message(Command("pending"))
async def command_pending_handler(message: Message) -> None:
    """Handle /pending command to show all pending payments (Req 2)."""
    if not is_admin(message.from_user.id):
        await message.answer("⚠️ Only authorized admins can view pending payments.")
        return

    try:
        pending_list = await get_pending_payments(limit=20)
        if not pending_list:
            await message.answer("⏳ <b>No pending payments found.</b>", parse_mode="HTML")
            return

        text = f"⏳ <b>Pending Payments ({len(pending_list)}):</b>\n\n"
        for idx, item in enumerate(pending_list, start=1):
            user_tag = f"@{item['username']}" if item.get('username') else item.get('full_name', 'User')
            text += (
                f"{idx}. <code>{item['payment_id']}</code> | 👤 {user_tag}\n"
                f"   • <b>Plan:</b> {item['plan_name']} | 💳 <b>Method:</b> {item['payment_method']}\n"
                f"   • <b>Submitted:</b> {item['created_at'][:16]}\n\n"
            )
        await message.answer(text, parse_mode="HTML")
        logger.info(f"Admin {message.from_user.id} requested /pending")
    except Exception as e:
        logger.error(f"Error executing /pending command: {e}")
        await message.answer("❌ An error occurred while fetching pending payments.")


@admin_router.message(Command("approved"))
async def command_approved_handler(message: Message) -> None:
    """Handle /approved command to show latest approved payments (Req 3)."""
    if not is_admin(message.from_user.id):
        await message.answer("⚠️ Only authorized admins can view approved payments.")
        return

    try:
        approved_list = await get_latest_approved_payments(limit=10)
        if not approved_list:
            await message.answer("✅ <b>No approved payments found.</b>", parse_mode="HTML")
            return

        text = f"✅ <b>Latest Approved Payments ({len(approved_list)}):</b>\n\n"
        for idx, item in enumerate(approved_list, start=1):
            user_tag = f"@{item['username']}" if item.get('username') else item.get('full_name', 'User')
            text += (
                f"{idx}. <code>{item['payment_id']}</code> | 👤 {user_tag}\n"
                f"   • <b>Plan:</b> {item['plan_name']} | 💳 <b>Method:</b> {item['payment_method']}\n"
                f"   • <b>Approved At:</b> {item['updated_at'][:16]}\n\n"
            )
        await message.answer(text, parse_mode="HTML")
        logger.info(f"Admin {message.from_user.id} requested /approved")
    except Exception as e:
        logger.error(f"Error executing /approved command: {e}")
        await message.answer("❌ An error occurred while fetching approved payments.")


@admin_router.message(Command("rejected"))
async def command_rejected_handler(message: Message) -> None:
    """Handle /rejected command to show latest rejected payments (Req 4)."""
    if not is_admin(message.from_user.id):
        await message.answer("⚠️ Only authorized admins can view rejected payments.")
        return

    try:
        rejected_list = await get_latest_rejected_payments(limit=10)
        if not rejected_list:
            await message.answer("❌ <b>No rejected payments found.</b>", parse_mode="HTML")
            return

        text = f"❌ <b>Latest Rejected Payments ({len(rejected_list)}):</b>\n\n"
        for idx, item in enumerate(rejected_list, start=1):
            user_tag = f"@{item['username']}" if item.get('username') else item.get('full_name', 'User')
            reason = item.get('rejection_reason') or 'Unspecified'
            text += (
                f"{idx}. <code>{item['payment_id']}</code> | 👤 {user_tag}\n"
                f"   • <b>Plan:</b> {item['plan_name']} | <b>Reason:</b> {reason}\n"
                f"   • <b>Rejected At:</b> {item['updated_at'][:16]}\n\n"
            )
        await message.answer(text, parse_mode="HTML")
        logger.info(f"Admin {message.from_user.id} requested /rejected")
    except Exception as e:
        logger.error(f"Error executing /rejected command: {e}")
        await message.answer("❌ An error occurred while fetching rejected payments.")


# --- Admin Payment Callback Handlers ---

@admin_router.callback_query(F.data.startswith("admin_approve:"))
async def process_admin_approve(callback: CallbackQuery, bot: Bot) -> None:
    """Handle Admin Approve button click (Req 3, 6)."""
    admin_id = callback.from_user.id
    if not is_admin(admin_id):
        await callback.answer("⚠️ Only authorized admins can review payments!", show_alert=True)
        return

    payment_id = callback.data.split(":")[1]
    payment = await get_payment_by_id(payment_id)

    if not payment:
        await callback.answer("❌ Payment record not found.", show_alert=True)
        return

    if payment["status"] != "PENDING":
        await callback.answer("This payment has already been processed.", show_alert=True)
        return

    admin_username = callback.from_user.username
    admin_identifier = f"@{admin_username}" if admin_username else callback.from_user.full_name

    user_id = payment["user_id"]
    plan_id = payment["plan_id"]
    duration_days = payment.get("duration_days", 0)
    product_type = payment.get("product_type", "vip")
    credit_amount = payment.get("credit_amount", 0)
    plan_name = payment.get("plan_name", "Studio99 Product")

    try:
        # Update database status & grant active subscription or credits
        await update_payment_status(payment_id, "APPROVED", admin_id)
        await grant_subscription(user_id, plan_id, duration_days)

        # Build user approval message
        if product_type == "credits":
            reply_markup = None
            user_msg = (
                "✅ <b>ငွေပေးချေမှု အတည်ပြုပြီးပါပြီ။</b>\n\n"
                f"• <b>Payment ID:</b> <code>{payment_id}</code>\n"
                f"• <b>Product:</b> {plan_name}\n"
                f"• <b>ထည့်သွင်းလိုက်သော Credits:</b> +{credit_amount} AI Credits 🎟\n\n"
                "Studio99 AI Credits ကို ဝယ်ယူအားပေးသည့်အတွက် ကျေးဇူးတင်ရှိပါသည်။"
            )
            if settings.PREMIUM_GROUP_LINK or settings.STUDIO99_DOWNLOAD_LINK:
                user_msg += f"\n\n🔗 <b>VIP Access Links:</b>"
                if settings.PREMIUM_GROUP_LINK:
                    user_msg += f"\n• <b>VIP Group:</b> {settings.PREMIUM_GROUP_LINK}"
                if settings.STUDIO99_DOWNLOAD_LINK:
                    user_msg += f"\n• <b>Download App:</b> {settings.STUDIO99_DOWNLOAD_LINK}"
            user_msg += FOOTER
        else:
            reply_markup = get_contact_admin_keyboard()
            user_msg = (
                "✅ <b>ငွေပေးချေမှု အတည်ပြုပြီးပါပြီ။</b>\n\n"
                "🎙 Voice Clone VIP ကို အသုံးပြုနိုင်ရန် Setup ပြုလုပ်ရန် လိုအပ်ပါသည်။\n\n"
                "အောက်ပါ \"💬 Contact Admin\" ခလုတ်ကို နှိပ်ပြီး Token ရယူကာ Setup အကူအညီ ရယူပါ။" + FOOTER
            )

        # Notify user
        try:
            await bot.send_message(chat_id=user_id, text=user_msg, parse_mode="HTML", reply_markup=reply_markup)
        except Exception as e:
            logger.error(f"Failed to send approval message to user {user_id}: {e}")

        # Update Admin Group message caption & disable buttons
        original_caption = callback.message.caption or ""
        new_caption = f"{original_caption}\n\n✅ <b>Approved by {admin_identifier}</b>"
        await callback.message.edit_caption(
            caption=new_caption,
            parse_mode="HTML",
            reply_markup=None
        )

        logger.info(f"Payment {payment_id} APPROVED by admin {admin_identifier} (User ID: {user_id})")
        await callback.answer("✅ Payment approved successfully!")

    except Exception as e:
        logger.error(f"Error during payment approval process ({payment_id}): {e}")
        await callback.answer("❌ Error processing payment approval.", show_alert=True)


@admin_router.callback_query(F.data.startswith("admin_reject:"))
async def process_admin_reject_prompt(callback: CallbackQuery) -> None:
    """Prompt admin to select a rejection reason (Req 5)."""
    admin_id = callback.from_user.id
    if not is_admin(admin_id):
        await callback.answer("⚠️ Only authorized admins can review payments!", show_alert=True)
        return

    payment_id = callback.data.split(":")[1]
    payment = await get_payment_by_id(payment_id)

    if not payment:
        await callback.answer("❌ Payment record not found.", show_alert=True)
        return

    if payment["status"] != "PENDING":
        await callback.answer("This payment has already been processed.", show_alert=True)
        return

    # Present reason selection keyboard to admin
    await callback.message.edit_reply_markup(
        reply_markup=get_admin_rejection_reasons_keyboard(payment_id)
    )
    await callback.answer("Please select a reason for rejection.")


@admin_router.callback_query(F.data.startswith("admin_cancel_reject:"))
async def cancel_reject_prompt(callback: CallbackQuery) -> None:
    """Restore original Approve/Reject buttons if admin cancels rejection selection."""
    payment_id = callback.data.split(":")[1]
    await callback.message.edit_reply_markup(
        reply_markup=get_admin_review_keyboard(payment_id)
    )
    await callback.answer()


@admin_router.callback_query(F.data.startswith("reject_reason:"))
async def process_admin_reject_reason(callback: CallbackQuery, bot: Bot) -> None:
    """Process selected rejection reason and notify user (Req 5)."""
    admin_id = callback.from_user.id
    if not is_admin(admin_id):
        await callback.answer("⚠️ Only authorized admins can review payments!", show_alert=True)
        return

    parts = callback.data.split(":", 2)
    payment_id = parts[1]
    selected_reason = parts[2]

    payment = await get_payment_by_id(payment_id)
    if not payment:
        await callback.answer("❌ Payment record not found.", show_alert=True)
        return

    if payment["status"] != "PENDING":
        await callback.answer("This payment has already been processed.", show_alert=True)
        return

    admin_username = callback.from_user.username
    admin_identifier = f"@{admin_username}" if admin_username else callback.from_user.full_name
    user_id = payment["user_id"]

    try:
        # Update database status
        await update_payment_status(
            payment_id=payment_id,
            status="REJECTED",
            reviewed_by=admin_id,
            rejection_reason=selected_reason
        )

        # Format user rejection message (Req 5)
        user_msg = (
            "❌ <b>Payment Rejected</b>\n\n"
            f"• <b>Payment ID:</b> <code>{payment_id}</code>\n\n"
            "<b>Reason:</b>\n"
            f"{selected_reason}\n\n"
            "Please upload another payment screenshot or contact support." + FOOTER
        )

        try:
            await bot.send_message(chat_id=user_id, text=user_msg, parse_mode="HTML")
        except Exception as e:
            logger.error(f"Failed to send rejection message to user {user_id}: {e}")

        # Update Admin Group message caption & disable buttons
        original_caption = callback.message.caption or ""
        new_caption = (
            f"{original_caption}\n\n"
            f"❌ <b>Rejected by {admin_identifier}</b>\n"
            f"<b>Reason:</b> {selected_reason}"
        )
        await callback.message.edit_caption(
            caption=new_caption,
            parse_mode="HTML",
            reply_markup=None
        )

        logger.info(f"Payment {payment_id} REJECTED by admin {admin_identifier} (Reason: {selected_reason})")
        await callback.answer(f"❌ Payment rejected ({selected_reason}).")

    except Exception as e:
        logger.error(f"Error during payment rejection process ({payment_id}): {e}")
        await callback.answer("❌ Error processing payment rejection.", show_alert=True)

