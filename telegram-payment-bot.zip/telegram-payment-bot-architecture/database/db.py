import os
import sqlite3
import asyncio
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

DB_PATH = os.getenv("DB_PATH", "payment_bot.db")


def _dict_factory(cursor: sqlite3.Cursor, row: tuple) -> Dict[str, Any]:
    """Convert SQLite row to dictionary."""
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


def _get_raw_connection(db_file: str = DB_PATH) -> sqlite3.Connection:
    """Get synchronous SQLite connection with Row dictionary factory."""
    conn = sqlite3.connect(db_file)
    conn.row_factory = _dict_factory
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def _sync_init_db(db_file: str = DB_PATH) -> None:
    """Synchronous DB schema initialization & default seed data insertion."""
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    
    if os.path.exists(schema_path):
        with open(schema_path, "r", encoding="utf-8") as f:
            schema_script = f.read()
        cursor.executescript(schema_script)
    else:
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            full_name TEXT NOT NULL,
            credits INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            price_mmk INTEGER NOT NULL,
            product_type TEXT DEFAULT 'vip',
            credit_amount INTEGER DEFAULT 0,
            duration_days INTEGER DEFAULT 0,
            description TEXT,
            is_active BOOLEAN DEFAULT 1
        );
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payment_id TEXT UNIQUE NOT NULL,
            user_id INTEGER NOT NULL,
            plan_id INTEGER NOT NULL,
            payment_method TEXT NOT NULL,
            screenshot_file_id TEXT NOT NULL,
            admin_message_id INTEGER,
            status TEXT DEFAULT 'PENDING',
            rejection_reason TEXT,
            reviewed_by INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (plan_id) REFERENCES subscriptions(id)
        );
        """)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            plan_id INTEGER NOT NULL,
            starts_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires_at TIMESTAMP NOT NULL,
            status TEXT DEFAULT 'ACTIVE',
            FOREIGN KEY (user_id) REFERENCES users(user_id),
            FOREIGN KEY (plan_id) REFERENCES subscriptions(id)
        );
        """)

    # Ensure columns exist in case of schema upgrade
    cursor.execute("PRAGMA table_info(users)")
    user_cols = [r["name"] for r in cursor.fetchall()]
    if "credits" not in user_cols:
        cursor.execute("ALTER TABLE users ADD COLUMN credits INTEGER DEFAULT 0")

    cursor.execute("PRAGMA table_info(subscriptions)")
    sub_cols = [r["name"] for r in cursor.fetchall()]
    if "product_type" not in sub_cols:
        cursor.execute("ALTER TABLE subscriptions ADD COLUMN product_type TEXT DEFAULT 'vip'")
    if "credit_amount" not in sub_cols:
        cursor.execute("ALTER TABLE subscriptions ADD COLUMN credit_amount INTEGER DEFAULT 0")

    cursor.execute("PRAGMA table_info(payments)")
    pay_cols = [r["name"] for r in cursor.fetchall()]
    if "studio99_account" not in pay_cols:
        cursor.execute("ALTER TABLE payments ADD COLUMN studio99_account TEXT")

    # Seed default products if table is empty or has old plans
    cursor.execute("SELECT name FROM subscriptions")
    existing_names = [r["name"] for r in cursor.fetchall()]
    
    default_products = [
        ("10 Credits", 1000, "credits", 10, 0, "Receive 10 AI Credits."),
        ("30 Credits", 3000, "credits", 30, 0, "Receive 30 AI Credits."),
        ("50 Credits", 5000, "credits", 50, 0, "Receive 50 AI Credits."),
        ("Voice Clone VIP - 1 Day", 500, "vip", 0, 1, "Unlimited Voice Clone access for 1 day."),
        ("Voice Clone VIP - 7 Days", 2500, "vip", 0, 7, "Unlimited Voice Clone access for 7 days."),
        ("Voice Clone VIP - 30 Days", 10000, "vip", 0, 30, "Unlimited Voice Clone access for 30 days.")
    ]

    if not existing_names or "1 Month VIP Access" in existing_names:
        cursor.execute("DELETE FROM subscriptions")
        cursor.executemany(
            "INSERT INTO subscriptions (name, price_mmk, product_type, credit_amount, duration_days, description) VALUES (?, ?, ?, ?, ?, ?)",
            default_products
        )
        conn.commit()
    conn.close()



async def init_db(db_file: str = DB_PATH) -> None:
    """Async wrapper for initializing database schema."""
    await asyncio.to_thread(_sync_init_db, db_file)


# --- Database CRUD Operations ---

def _sync_add_or_update_user(user_id: int, username: Optional[str], full_name: str, db_file: str) -> None:
    conn = _get_raw_connection(db_file)
    conn.execute("""
        INSERT INTO users (user_id, username, full_name)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username = excluded.username,
            full_name = excluded.full_name;
    """, (user_id, username, full_name))
    conn.commit()
    conn.close()

async def add_or_update_user(user_id: int, username: Optional[str], full_name: str, db_file: str = DB_PATH) -> None:
    """Register or update user details upon /start command."""
    await asyncio.to_thread(_sync_add_or_update_user, user_id, username, full_name, db_file)


def _sync_get_user(user_id: int, db_file: str) -> Optional[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

async def get_user(user_id: int, db_file: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Fetch user record by Telegram User ID."""
    return await asyncio.to_thread(_sync_get_user, user_id, db_file)


def _sync_get_user_credits(user_id: int, db_file: str) -> int:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT credits FROM users WHERE user_id = ?", (user_id,))
    row = cursor.fetchone()
    conn.close()
    return row["credits"] if row and row.get("credits") is not None else 0

async def get_user_credits(user_id: int, db_file: str = DB_PATH) -> int:
    """Fetch AI credits balance for user."""
    return await asyncio.to_thread(_sync_get_user_credits, user_id, db_file)


def _sync_get_subscription_plans(only_active: bool, db_file: str) -> List[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = "SELECT * FROM subscriptions" + (" WHERE is_active = 1" if only_active else "") + " ORDER BY id ASC"
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

async def get_subscription_plans(only_active: bool = True, db_file: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve available subscription plans."""
    return await asyncio.to_thread(_sync_get_subscription_plans, only_active, db_file)


def _sync_get_plan_by_id(plan_id: int, db_file: str) -> Optional[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM subscriptions WHERE id = ?", (plan_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

async def get_plan_by_id(plan_id: int, db_file: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Fetch single plan by ID."""
    return await asyncio.to_thread(_sync_get_plan_by_id, plan_id, db_file)


def _sync_create_payment(
    payment_id: str,
    user_id: int,
    plan_id: int,
    payment_method: str,
    screenshot_file_id: str,
    studio99_account: Optional[str],
    db_file: str
) -> Dict[str, Any]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO payments (payment_id, user_id, plan_id, payment_method, screenshot_file_id, studio99_account, status)
        VALUES (?, ?, ?, ?, ?, ?, 'PENDING')
    """, (payment_id, user_id, plan_id, payment_method, screenshot_file_id, studio99_account))
    conn.commit()
    
    cursor.execute("SELECT * FROM payments WHERE payment_id = ?", (payment_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row)

async def create_payment(
    payment_id: str,
    user_id: int,
    plan_id: int,
    payment_method: str,
    screenshot_file_id: str,
    studio99_account: Optional[str] = None,
    db_file: str = DB_PATH
) -> Dict[str, Any]:
    """Create a new pending payment entry."""
    return await asyncio.to_thread(_sync_create_payment, payment_id, user_id, plan_id, payment_method, screenshot_file_id, studio99_account, db_file)


def _sync_set_admin_message_id(payment_id: str, admin_message_id: int, db_file: str) -> None:
    conn = _get_raw_connection(db_file)
    conn.execute(
        "UPDATE payments SET admin_message_id = ?, updated_at = CURRENT_TIMESTAMP WHERE payment_id = ?",
        (admin_message_id, payment_id)
    )
    conn.commit()
    conn.close()

async def set_admin_message_id(payment_id: str, admin_message_id: int, db_file: str = DB_PATH) -> None:
    """Link Telegram message ID sent to admin group with payment record."""
    await asyncio.to_thread(_sync_set_admin_message_id, payment_id, admin_message_id, db_file)


def _sync_get_payment_by_id(payment_id: str, db_file: str) -> Optional[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = """
        SELECT p.*, u.username, u.full_name, u.credits as user_credits,
               s.name as plan_name, s.price_mmk, s.product_type, s.credit_amount, s.duration_days, s.description as plan_description
        FROM payments p
        JOIN users u ON p.user_id = u.user_id
        JOIN subscriptions s ON p.plan_id = s.id
        WHERE p.payment_id = ?
    """
    cursor.execute(query, (payment_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

async def get_payment_by_id(payment_id: str, db_file: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Get payment detailed info joined with user and plan details."""
    return await asyncio.to_thread(_sync_get_payment_by_id, payment_id, db_file)


def _sync_update_payment_status(
    payment_id: str,
    status: str,
    reviewed_by: int,
    rejection_reason: Optional[str],
    db_file: str
) -> Optional[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    conn.execute("""
        UPDATE payments 
        SET status = ?, reviewed_by = ?, rejection_reason = ?, updated_at = CURRENT_TIMESTAMP
        WHERE payment_id = ?
    """, (status, reviewed_by, rejection_reason, payment_id))
    conn.commit()
    conn.close()
    return _sync_get_payment_by_id(payment_id, db_file)

async def update_payment_status(
    payment_id: str,
    status: str,
    reviewed_by: int,
    rejection_reason: Optional[str] = None,
    db_file: str = DB_PATH
) -> Optional[Dict[str, Any]]:
    """Approve or Reject payment."""
    return await asyncio.to_thread(_sync_update_payment_status, payment_id, status, reviewed_by, rejection_reason, db_file)


def _sync_grant_subscription(user_id: int, plan_id: int, duration_days: int, db_file: str) -> Dict[str, Any]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM subscriptions WHERE id = ?", (plan_id,))
    plan = cursor.fetchone()
    
    if not plan:
        conn.close()
        # Fallback to duration_days if plan not found
        product_type = "vip"
        credit_amount = 0
    else:
        product_type = plan.get("product_type", "vip")
        credit_amount = plan.get("credit_amount", 0)
        if duration_days <= 0:
            duration_days = plan.get("duration_days", 0)

    now = datetime.utcnow()
    
    if product_type == "credits":
        cursor.execute("UPDATE users SET credits = COALESCE(credits, 0) + ? WHERE user_id = ?", (credit_amount, user_id))
        conn.commit()
        conn.close()
        return {
            "user_id": user_id,
            "plan_id": plan_id,
            "product_type": "credits",
            "credit_amount": credit_amount,
            "status": "GRANTED"
        }
    else:
        cursor.execute(
            "SELECT * FROM user_subscriptions WHERE user_id = ? AND status = 'ACTIVE' AND expires_at > CURRENT_TIMESTAMP ORDER BY expires_at DESC LIMIT 1",
            (user_id,)
        )
        existing = cursor.fetchone()
        
        if existing:
            current_expires = datetime.fromisoformat(existing["expires_at"])
            new_expires = current_expires + timedelta(days=duration_days)
            conn.execute(
                "UPDATE user_subscriptions SET expires_at = ? WHERE id = ?",
                (new_expires.isoformat(), existing["id"])
            )
            starts_at = existing["starts_at"]
        else:
            starts_at = now.isoformat()
            new_expires = now + timedelta(days=duration_days)
            conn.execute("""
                INSERT INTO user_subscriptions (user_id, plan_id, starts_at, expires_at, status)
                VALUES (?, ?, ?, ?, 'ACTIVE')
            """, (user_id, plan_id, starts_at, new_expires.isoformat()))
        
        conn.commit()
        conn.close()
        return {
            "user_id": user_id,
            "plan_id": plan_id,
            "product_type": "vip",
            "starts_at": starts_at,
            "expires_at": new_expires.isoformat(),
            "status": "ACTIVE"
        }

async def grant_subscription(user_id: int, plan_id: int, duration_days: int = 0, db_file: str = DB_PATH) -> Dict[str, Any]:
    """Grant or extend user subscription or AI credits after payment approval."""
    return await asyncio.to_thread(_sync_grant_subscription, user_id, plan_id, duration_days, db_file)


def _sync_get_pending_payment_by_user(user_id: int, db_file: str) -> Optional[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = """
        SELECT p.*, s.name as plan_name, s.price_mmk
        FROM payments p
        JOIN subscriptions s ON p.plan_id = s.id
        WHERE p.user_id = ? AND p.status = 'PENDING'
        ORDER BY p.created_at DESC LIMIT 1
    """
    cursor.execute(query, (user_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

async def get_pending_payment_by_user(user_id: int, db_file: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Retrieve pending payment for user if one exists."""
    return await asyncio.to_thread(_sync_get_pending_payment_by_user, user_id, db_file)


def _sync_get_active_user_subscription(user_id: int, db_file: str) -> Optional[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = """
        SELECT us.*, s.name as plan_name, s.price_mmk
        FROM user_subscriptions us
        JOIN subscriptions s ON us.plan_id = s.id
        WHERE us.user_id = ? AND us.status = 'ACTIVE' AND us.expires_at > CURRENT_TIMESTAMP
        ORDER BY us.expires_at DESC LIMIT 1
    """
    cursor.execute(query, (user_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

async def get_active_user_subscription(user_id: int, db_file: str = DB_PATH) -> Optional[Dict[str, Any]]:
    """Retrieve active subscription for user if exists."""
    return await asyncio.to_thread(_sync_get_active_user_subscription, user_id, db_file)


# --- Phase 5 Admin Query Functions ---

def _sync_get_bot_stats(db_file: str) -> Dict[str, int]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) as total FROM users")
    total_users = cursor.fetchone()["total"]
    
    cursor.execute("SELECT COUNT(*) as total FROM payments")
    total_payments = cursor.fetchone()["total"]
    
    cursor.execute("SELECT COUNT(*) as total FROM payments WHERE status = 'PENDING'")
    pending_payments = cursor.fetchone()["total"]
    
    cursor.execute("SELECT COUNT(*) as total FROM payments WHERE status = 'APPROVED'")
    approved_payments = cursor.fetchone()["total"]
    
    cursor.execute("SELECT COUNT(*) as total FROM payments WHERE status = 'REJECTED'")
    rejected_payments = cursor.fetchone()["total"]
    
    conn.close()
    return {
        "total_users": total_users,
        "total_payments": total_payments,
        "pending_payments": pending_payments,
        "approved_payments": approved_payments,
        "rejected_payments": rejected_payments
    }

async def get_bot_stats(db_file: str = DB_PATH) -> Dict[str, int]:
    """Retrieve overall statistics for /stats command."""
    return await asyncio.to_thread(_sync_get_bot_stats, db_file)


def _sync_get_pending_payments(limit: int, db_file: str) -> List[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = """
        SELECT p.*, u.username, u.full_name, s.name as plan_name
        FROM payments p
        JOIN users u ON p.user_id = u.user_id
        JOIN subscriptions s ON p.plan_id = s.id
        WHERE p.status = 'PENDING'
        ORDER BY p.created_at DESC LIMIT ?
    """
    cursor.execute(query, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

async def get_pending_payments(limit: int = 20, db_file: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve pending payments for /pending command."""
    return await asyncio.to_thread(_sync_get_pending_payments, limit, db_file)


def _sync_get_latest_approved_payments(limit: int, db_file: str) -> List[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = """
        SELECT p.*, u.username, u.full_name, s.name as plan_name
        FROM payments p
        JOIN users u ON p.user_id = u.user_id
        JOIN subscriptions s ON p.plan_id = s.id
        WHERE p.status = 'APPROVED'
        ORDER BY p.updated_at DESC LIMIT ?
    """
    cursor.execute(query, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

async def get_latest_approved_payments(limit: int = 10, db_file: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve latest approved payments for /approved command."""
    return await asyncio.to_thread(_sync_get_latest_approved_payments, limit, db_file)


def _sync_get_latest_rejected_payments(limit: int, db_file: str) -> List[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = """
        SELECT p.*, u.username, u.full_name, s.name as plan_name
        FROM payments p
        JOIN users u ON p.user_id = u.user_id
        JOIN subscriptions s ON p.plan_id = s.id
        WHERE p.status = 'REJECTED'
        ORDER BY p.updated_at DESC LIMIT ?
    """
    cursor.execute(query, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

async def get_latest_rejected_payments(limit: int = 10, db_file: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve latest rejected payments for /rejected command."""
    return await asyncio.to_thread(_sync_get_latest_rejected_payments, limit, db_file)

