import os
from typing import List
from dataclasses import dataclass, field

# Try loading .env file if python-dotenv is available, otherwise simple parser
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    if os.path.exists(".env"):
        with open(".env", "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    os.environ.setdefault(key.strip(), value.strip())


@dataclass
class Settings:
    """Configuration settings loaded from environment variables."""
    BOT_TOKEN: str = field(default_factory=lambda: os.getenv("BOT_TOKEN", "7890123456:AAFx_example_bot_token_here"))
    ADMIN_GROUP_ID: int = field(default_factory=lambda: int(os.getenv("ADMIN_GROUP_ID", "-1001987654321")))
    ADMIN_IDS_STR: str = field(default_factory=lambda: os.getenv("ADMIN_IDS", "123456789,987654321"))
    
    # Payment Accounts
    KBZPAY_NO: str = field(default_factory=lambda: os.getenv("KBZPAY_NO", "09123456789"))
    KBZPAY_NAME: str = field(default_factory=lambda: os.getenv("KBZPAY_NAME", "U Ba Maung"))
    WAVEPAY_NO: str = field(default_factory=lambda: os.getenv("WAVEPAY_NO", "09987654321"))
    WAVEPAY_NAME: str = field(default_factory=lambda: os.getenv("WAVEPAY_NAME", "U Ba Maung"))
    
    # VIP Links & Support (Optional)
    PREMIUM_GROUP_LINK: str = field(default_factory=lambda: os.getenv("PREMIUM_GROUP_LINK", "").strip())
    STUDIO99_DOWNLOAD_LINK: str = field(default_factory=lambda: os.getenv("STUDIO99_DOWNLOAD_LINK", "").strip())
    SUPPORT_ADMIN_URL: str = field(default_factory=lambda: os.getenv("SUPPORT_ADMIN_URL", "").strip())

    # Database
    DB_PATH: str = field(default_factory=lambda: os.getenv("DB_PATH", "payment_bot.db"))

    @property
    def admin_ids(self) -> List[int]:
        """Parse comma-separated admin IDs into a list of integers."""
        if not self.ADMIN_IDS_STR:
            return []
        try:
            return [int(x.strip()) for x in self.ADMIN_IDS_STR.split(",") if x.strip()]
        except ValueError:
            return []

    def verify_config(self) -> None:
        """Perform startup checks for mandatory configuration variables."""
        missing = []
        if not self.BOT_TOKEN:
            missing.append("BOT_TOKEN")
        if not self.ADMIN_GROUP_ID:
            missing.append("ADMIN_GROUP_ID")
        if not self.admin_ids:
            missing.append("ADMIN_IDS")
        if not self.KBZPAY_NO or not self.WAVEPAY_NO:
            missing.append("Payment Account Configuration (KBZPAY_NO / WAVEPAY_NO)")

        if missing:
            raise ValueError(f"CRITICAL: Missing or invalid required startup parameters: {', '.join(missing)}")


settings = Settings()
