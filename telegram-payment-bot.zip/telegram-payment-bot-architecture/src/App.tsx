import React, { useState } from 'react';
import { 
  FolderTree, 
  Database, 
  CheckCircle2, 
  Circle, 
  Code2, 
  Copy, 
  Check, 
  Terminal, 
  Play, 
  Layers, 
  ShieldCheck, 
  Bot, 
  QrCode, 
  CreditCard, 
  ArrowRight, 
  Search, 
  FileText, 
  KeyRound, 
  RefreshCw,
  Sparkles,
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import { PROJECT_FILES, SCHEMA_TABLES, INITIAL_SEEDED_PLANS, FileItem } from './data/projectData';

export default function App() {
  const [activeTab, setActiveTab] = useState<'roadmap' | 'files' | 'schema' | 'playground' | 'guide'>('roadmap');
  const [selectedFile, setSelectedFile] = useState<FileItem>(PROJECT_FILES[1]); // config.py default
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Playground state
  const [simUser, setSimUser] = useState({ id: 99887766, username: 'aung_aung', name: 'Aung Aung' });
  const [simPlanId, setSimPlanId] = useState<number>(1);
  const [simPaymentMethod, setSimPaymentMethod] = useState<'KBZPay' | 'WavePay'>('KBZPay');
  const [simPayments, setSimPayments] = useState<any[]>([
    {
      payment_id: 'PAY-2026-1001',
      user_id: 99887766,
      user_name: 'Aung Aung',
      username: 'aung_aung',
      plan_name: '1 Month VIP Access',
      price_mmk: 10000,
      duration_days: 30,
      method: 'KBZPay',
      screenshot_file_id: 'AgACAgUAAx0C...',
      status: 'PENDING',
      created_at: new Date().toISOString()
    }
  ]);
  const [simActiveSub, setSimActiveSub] = useState<any | null>(null);
  const [rejectionReason, setRejectionReason] = useState('Payment screenshot unreadable or incomplete');

  const copyToClipboard = (text: string, identifier: string) => {
    navigator.clipboard.writeText(text);
    setCopiedPath(identifier);
    setTimeout(() => setCopiedPath(null), 2000);
  };

  const handleSimulatePayment = () => {
    const selectedPlan = INITIAL_SEEDED_PLANS.find(p => p.id === simPlanId) || INITIAL_SEEDED_PLANS[0];
    const newPayId = `PAY-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newPayment = {
      payment_id: newPayId,
      user_id: simUser.id,
      user_name: simUser.name,
      username: simUser.username,
      plan_name: selectedPlan.name,
      price_mmk: selectedPlan.price_mmk,
      duration_days: selectedPlan.duration_days,
      method: simPaymentMethod,
      screenshot_file_id: `AgACAgUAAx0C_${Math.random().toString(36).substring(7)}`,
      status: 'PENDING',
      created_at: new Date().toISOString()
    };
    setSimPayments([newPayment, ...simPayments]);
  };

  const handleApprovePayment = (payId: string) => {
    setSimPayments(prev => prev.map(p => {
      if (p.payment_id === payId) {
        const expiresDate = new Date();
        expiresDate.setDate(expiresDate.getDate() + p.duration_days);
        setSimActiveSub({
          user_id: p.user_id,
          plan_name: p.plan_name,
          starts_at: new Date().toISOString().split('T')[0],
          expires_at: expiresDate.toISOString().split('T')[0],
          status: 'ACTIVE'
        });
        return { ...p, status: 'APPROVED', reviewed_by: 123456789 };
      }
      return p;
    }));
  };

  const handleRejectPayment = (payId: string) => {
    setSimPayments(prev => prev.map(p => {
      if (p.payment_id === payId) {
        return { ...p, status: 'REJECTED', rejection_reason: rejectionReason, reviewed_by: 123456789 };
      }
      return p;
    }));
  };

  const filteredFiles = PROJECT_FILES.filter(f => 
    f.path.toLowerCase().includes(searchQuery.toLowerCase()) || 
    f.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow-lg shadow-indigo-500/20">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white">Telegram Payment Bot</h1>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold">
                  Phase 1, 2, 3, 4 & 5 Complete (100%)
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                aiogram 3.x • SQLite3 • Admin Tools (/stats, /pending, /approved, /rejected) • Production Ready
              </p>
            </div>
          </div>

          {/* Quick Badges */}
          <div className="flex items-center gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 border border-slate-700 font-mono">
              Python 3.10+
            </span>
            <span className="px-2.5 py-1 rounded-md bg-indigo-950 text-indigo-300 border border-indigo-800 font-mono">
              aiogram 3.17+
            </span>
            <span className="px-2.5 py-1 rounded-md bg-purple-950 text-purple-300 border border-purple-800 font-mono">
              SQLite DB
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex overflow-x-auto gap-1 border-t border-slate-800/60 pt-2">
          <button
            onClick={() => setActiveTab('roadmap')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'roadmap'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <Layers className="w-4 h-4" />
            Phase Architecture & Flow
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'files'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <FolderTree className="w-4 h-4" />
            Project File Explorer ({PROJECT_FILES.length})
          </button>

          <button
            onClick={() => setActiveTab('schema')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'schema'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <Database className="w-4 h-4" />
            Database Schema (4 Tables)
          </button>

          <button
            onClick={() => setActiveTab('playground')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'playground'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <Play className="w-4 h-4" />
            Live DB Simulator
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-t-lg border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'guide'
                ? 'border-indigo-500 text-indigo-400 bg-slate-900'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
            }`}
          >
            <Terminal className="w-4 h-4" />
            Setup & Execution Guide
          </button>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

        {/* TAB 1: ROADMAP & ARCHITECTURE */}
        {activeTab === 'roadmap' && (
          <div className="space-y-8">
            {/* Status Header */}
            <div className="bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 rounded-2xl p-6">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-6 h-6 text-indigo-400" />
                    Telegram Payment Bot - Development Phases
                  </h2>
                  <p className="text-slate-400 text-sm mt-1 max-w-3xl">
                    All 5 Phases (Project Setup, Database Layer, User Workflow, Admin Group Review, and Production Polish & Admin Tools) are 100% complete and fully verified with automated Python tests.
                  </p>
                </div>
                <div className="text-right hidden sm:block">
                  <span className="text-3xl font-extrabold text-emerald-400">100%</span>
                  <p className="text-xs text-slate-400">Overall Progress</p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mt-6">
                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-emerald-500 to-indigo-500 w-full"></div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-xs font-medium">
                  <div className="text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> Phase 1: Project Setup (Completed)
                  </div>
                  <div className="text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> Phase 2: Database Layer (Completed)
                  </div>
                  <div className="text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> Phase 3: User Workflow (Completed)
                  </div>
                  <div className="text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" /> Phase 4: Admin Review (Completed)
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Phase Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Phase 1 Card */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-bl-lg border-b border-l border-emerald-500/30">
                  COMPLETED
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
                    1
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">Phase 1: Project Setup</h3>
                    <p className="text-xs text-slate-400">Environment & Config Structure</p>
                  </div>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-slate-300">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Created <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">.env.example</code> with token, admin & payment accounts
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Created <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">requirements.txt</code> with aiogram 3.x & aiosqlite
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Created <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">config.py</code> settings loader with admin parsing
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Setup clean folder structure (<code className="text-xs bg-slate-800 px-1 py-0.5 rounded">database/</code>, <code className="text-xs bg-slate-800 px-1 py-0.5 rounded">handlers/</code>, etc.)
                  </li>
                </ul>
              </div>

              {/* Phase 2 Card */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-bl-lg border-b border-l border-emerald-500/30">
                  COMPLETED
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
                    2
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">Phase 2: Database Layer</h3>
                    <p className="text-xs text-slate-400">SQLite Schema & CRUD Manager</p>
                  </div>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-slate-300">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Created <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">database/schema.sql</code> (4 relational tables & indexes)
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Created <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">database/db.py</code> async CRUD queries
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Automatic seeding of 1 Month, 3 Month & 1 Year VIP plans
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Created <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">test_database.py</code> test suite (100% Passing)
                  </li>
                </ul>
              </div>

              {/* Phase 3 Card */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-bl-lg border-b border-l border-emerald-500/30">
                  COMPLETED
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
                    3
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">Phase 3: User Workflow</h3>
                    <p className="text-xs text-slate-400">Handlers, Keyboards & FSM States</p>
                  </div>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-slate-300">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Implemented <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">handlers/user.py</code> router (/start, plan selection)
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Implemented <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">keyboards/inline.py</code> builders (KBZPay, WavePay, Cancel)
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Implemented <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">states/payment.py</code> FSM state flow
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Duplicate pending payment prevention & admin forwarding
                  </li>
                </ul>
              </div>

              {/* Phase 4 Card */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-bl-lg border-b border-l border-emerald-500/30">
                  COMPLETED
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
                    4
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">Phase 4: Admin Review Workflow</h3>
                    <p className="text-xs text-slate-400">Approve/Reject Callbacks, Auth & Notifications</p>
                  </div>
                </div>
                <ul className="mt-4 space-y-2 text-sm text-slate-300">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Implemented <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">handlers/admin.py</code> router
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Admin auth check (`ADMIN_IDS`) & double-processing prevention
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Approve / Reject callbacks, DB subscription extension & user alerts
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-400" /> Payment copy number code block, upload prompt & photo-only filter
                  </li>
                </ul>
              </div>

              {/* Phase 5 Card */}
              <div className="bg-slate-900/90 border border-emerald-500/30 rounded-xl p-6 relative overflow-hidden md:col-span-2">
                <div className="absolute top-0 right-0 px-3 py-1 bg-emerald-500/20 text-emerald-400 text-xs font-semibold rounded-bl-lg border-b border-l border-emerald-500/30">
                  COMPLETED
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-bold text-lg">
                    5
                  </div>
                  <div>
                    <h3 className="font-bold text-white text-lg">Phase 5: Production Polish & Admin Tools</h3>
                    <p className="text-xs text-slate-400">Admin Commands (/stats, /pending, /approved, /rejected), Rejection Reasons & Logging</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 text-sm text-slate-300">
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" /> <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">/stats</code> command (Users, Payments, Pending, Approved, Rejected)
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" /> <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">/pending</code>, <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">/approved</code> & <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">/rejected</code> command reports
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" /> Interactive Rejection Reasons (Wrong Amount, Clear Pic, Not Found, Other)
                    </li>
                  </ul>
                  <ul className="space-y-2">
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" /> Automated approval message with optional VIP Group & Download links
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" /> Dual Logging System console & <code className="text-xs bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">logs/bot.log</code> file logging
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-400" /> Startup config checks, Dockerfile, Procfile & Deployment guide
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* End-to-End Bot Flow Visualization */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <Bot className="w-5 h-5 text-indigo-400" />
                Telegram Payment Bot Architecture Flow
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
                {/* Step 1 */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center">
                  <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold flex items-center justify-center mx-auto mb-2 text-xs">
                    1
                  </div>
                  <h4 className="font-semibold text-white text-sm">/start Command</h4>
                  <p className="text-xs text-slate-400 mt-1">Registers user profile into <code className="text-indigo-300">users</code> table.</p>
                </div>

                {/* Step 2 */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center">
                  <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold flex items-center justify-center mx-auto mb-2 text-xs">
                    2
                  </div>
                  <h4 className="font-semibold text-white text-sm">Select VIP Plan</h4>
                  <p className="text-xs text-slate-400 mt-1">Shows subscription options (10k, 25k, 80k MMK).</p>
                </div>

                {/* Step 3 */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center">
                  <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold flex items-center justify-center mx-auto mb-2 text-xs">
                    3
                  </div>
                  <h4 className="font-semibold text-white text-sm">Upload Screenshot</h4>
                  <p className="text-xs text-slate-400 mt-1">Shows KBZPay/WavePay numbers; user uploads image.</p>
                </div>

                {/* Step 4 */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center">
                  <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold flex items-center justify-center mx-auto mb-2 text-xs">
                    4
                  </div>
                  <h4 className="font-semibold text-white text-sm">Admin Review</h4>
                  <p className="text-xs text-slate-400 mt-1">Forwards photo to Admin Group with Approve/Reject buttons.</p>
                </div>

                {/* Step 5 */}
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center">
                  <div className="w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold flex items-center justify-center mx-auto mb-2 text-xs">
                    5
                  </div>
                  <h4 className="font-semibold text-white text-sm">Grant or Reject</h4>
                  <p className="text-xs text-slate-400 mt-1">Auto-notifies user; extends expiration date on DB.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: PROJECT FILE EXPLORER */}
        {activeTab === 'files' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Sidebar File Tree */}
            <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <FolderTree className="w-4 h-4 text-indigo-400" />
                  Generated Files
                </h3>
                <span className="text-xs text-slate-400">{PROJECT_FILES.length} Files</span>
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Filter files..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* List */}
              <div className="space-y-1 max-h-[500px] overflow-y-auto pr-1">
                {filteredFiles.map((file) => (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg border text-xs transition-all flex items-center justify-between ${
                      selectedFile.path === file.path
                        ? 'bg-indigo-950/60 border-indigo-500/50 text-indigo-300 font-medium'
                        : 'bg-slate-950/40 border-slate-800/60 text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Code2 className="w-4 h-4 shrink-0 text-slate-400" />
                      <span className="truncate font-mono">{file.path}</span>
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 shrink-0 text-slate-500" />
                  </button>
                ))}
              </div>
            </div>

            {/* Right Viewer */}
            <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl overflow-hidden flex flex-col">
              {/* Header */}
              <div className="px-5 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-indigo-400 text-sm">{selectedFile.path}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                      {selectedFile.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">{selectedFile.description}</p>
                </div>

                <button
                  onClick={() => copyToClipboard(selectedFile.code, selectedFile.path)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all"
                >
                  {copiedPath === selectedFile.path ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Copy Code
                    </>
                  )}
                </button>
              </div>

              {/* Code View */}
              <div className="p-5 bg-slate-950 overflow-x-auto font-mono text-xs text-slate-200 leading-relaxed max-h-[600px] overflow-y-auto">
                <pre>{selectedFile.code}</pre>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: DATABASE SCHEMA & TABLES */}
        {activeTab === 'schema' && (
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Database className="w-5 h-5 text-indigo-400" />
                  SQLite Relational Database Architecture
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Defined in <code className="text-indigo-300">database/schema.sql</code> and executed asynchronously by <code className="text-indigo-300">database/db.py</code>.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg border border-slate-700">
                  Foreign Keys Enabled
                </span>
                <span className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg border border-slate-700">
                  WAL Mode Support
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {SCHEMA_TABLES.map((table) => (
                <div key={table.name} className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden">
                  <div className="px-5 py-3.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
                      <h4 className="font-mono font-bold text-white text-sm">{table.name}</h4>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">{table.columns.length} columns</span>
                  </div>

                  <div className="p-4">
                    <p className="text-xs text-slate-400 mb-3">{table.description}</p>
                    <div className="border border-slate-800 rounded-lg overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-950 text-slate-400 font-medium">
                          <tr>
                            <th className="p-2.5">Column</th>
                            <th className="p-2.5">Type</th>
                            <th className="p-2.5">Constraint</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                          {table.columns.map((col) => (
                            <tr key={col.name} className="hover:bg-slate-800/30">
                              <td className="p-2.5 font-bold text-indigo-300">{col.name}</td>
                              <td className="p-2.5 text-purple-300">{col.type}</td>
                              <td className="p-2.5 text-slate-400 text-[11px]">{col.constraints}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: LIVE DB SIMULATOR */}
        {activeTab === 'playground' && (
          <div className="space-y-8">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Play className="w-5 h-5 text-indigo-400" />
                Interactive Database & Payment Flow Simulator
              </h3>
              <p className="text-xs text-slate-400">
                Simulate Phase 2 database state changes in real-time. Test adding a payment screenshot entry, approving or rejecting payments, and verifying subscription granting.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Left Controls */}
              <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-indigo-400" />
                  Simulate New User Payment
                </h4>

                {/* User Input */}
                <div className="space-y-3">
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Telegram User Name</label>
                    <input
                      type="text"
                      value={simUser.name}
                      onChange={(e) => setSimUser({ ...simUser, name: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  {/* Plan Select */}
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Select Subscription Plan</label>
                    <select
                      value={simPlanId}
                      onChange={(e) => setSimPlanId(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      {INITIAL_SEEDED_PLANS.map(p => (
                        <option key={p.id} value={p.id}>
                          {p.name} - {p.price_mmk.toLocaleString()} MMK ({p.duration_days} Days)
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Payment Method */}
                  <div>
                    <label className="text-xs text-slate-400 block mb-1">Payment Method</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => setSimPaymentMethod('KBZPay')}
                        className={`py-2 text-xs font-semibold rounded-lg border ${
                          simPaymentMethod === 'KBZPay'
                            ? 'bg-blue-600 border-blue-500 text-white'
                            : 'bg-slate-950 border-slate-800 text-slate-400'
                        }`}
                      >
                        KBZPay
                      </button>
                      <button
                        onClick={() => setSimPaymentMethod('WavePay')}
                        className={`py-2 text-xs font-semibold rounded-lg border ${
                          simPaymentMethod === 'WavePay'
                            ? 'bg-yellow-600 border-yellow-500 text-white'
                            : 'bg-slate-950 border-slate-800 text-slate-400'
                        }`}
                      >
                        WavePay
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={handleSimulatePayment}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-2"
                  >
                    <Play className="w-3.5 h-3.5" /> Submit Payment Screenshot
                  </button>
                </div>

                {/* Active Sub Card */}
                {simActiveSub && (
                  <div className="mt-6 border border-emerald-500/30 bg-emerald-950/20 rounded-xl p-4 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Active Subscription
                      </span>
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">
                        ACTIVE
                      </span>
                    </div>
                    <div className="text-xs text-slate-300 font-mono space-y-1">
                      <p>Plan: <strong className="text-white">{simActiveSub.plan_name}</strong></p>
                      <p>Starts: {simActiveSub.starts_at}</p>
                      <p>Expires: <strong className="text-emerald-400">{simActiveSub.expires_at}</strong></p>
                    </div>
                  </div>
                )}
              </div>

              {/* Right Admin Review Group Simulator */}
              <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-white text-sm flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-indigo-400" />
                    Admin Group Review Queue ({simPayments.length})
                  </h4>
                  <span className="text-[11px] text-slate-400">Multi-Admin Review Enabled</span>
                </div>

                <div className="space-y-3 max-h-[450px] overflow-y-auto pr-1">
                  {simPayments.map((p) => (
                    <div
                      key={p.payment_id}
                      className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs space-y-3"
                    >
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-indigo-300">{p.payment_id}</span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            p.status === 'PENDING' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                            p.status === 'APPROVED' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                            'bg-red-500/20 text-red-400 border border-red-500/30'
                          }`}>
                            {p.status}
                          </span>
                        </div>
                        <span className="text-slate-500 text-[10px]">{new Date(p.created_at).toLocaleTimeString()}</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-slate-300 font-mono">
                        <div>User: <strong className="text-white">{p.user_name}</strong> (@{p.username})</div>
                        <div>Plan: <strong className="text-white">{p.plan_name}</strong></div>
                        <div>Amount: <strong className="text-indigo-400">{p.price_mmk.toLocaleString()} MMK</strong></div>
                        <div>Method: <strong className="text-purple-300">{p.method}</strong></div>
                      </div>

                      {p.status === 'PENDING' && (
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                          <button
                            onClick={() => handleApprovePayment(p.payment_id)}
                            className="flex-1 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-all"
                          >
                            Approve & Grant VIP
                          </button>
                          <button
                            onClick={() => handleRejectPayment(p.payment_id)}
                            className="flex-1 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg transition-all"
                          >
                            Reject Payment
                          </button>
                        </div>
                      )}

                      {p.status === 'APPROVED' && (
                        <div className="text-emerald-400 text-[11px] font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Approved by Admin #123456789. User granted {p.duration_days} Days.
                        </div>
                      )}

                      {p.status === 'REJECTED' && (
                        <div className="text-red-400 text-[11px] font-semibold">
                          Rejected: {p.rejection_reason}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: SETUP & EXECUTION GUIDE */}
        {activeTab === 'guide' && (
          <div className="space-y-8">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-2 flex items-center gap-2">
                <Terminal className="w-5 h-5 text-indigo-400" />
                Phase 1 & 2 Execution Guide
              </h3>
              <p className="text-xs text-slate-400">
                How to configure environment secrets and execute Phase 1 & 2 Python verification scripts.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Command 1 */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <Play className="w-4 h-4 text-emerald-400" />
                  1. Run Automated Test Suite
                </h4>
                <p className="text-xs text-slate-400">
                  Validates database table creation, foreign key constraints, default seeding, and payment status updates.
                </p>
                <div className="bg-slate-950 p-3 rounded-lg font-mono text-xs text-emerald-400 border border-slate-800 flex items-center justify-between">
                  <code>python3 test_database.py</code>
                  <button
                    onClick={() => copyToClipboard('python3 test_database.py', 'test_cmd')}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400"
                  >
                    {copiedPath === 'test_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Command 2 */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
                <h4 className="font-bold text-white text-sm flex items-center gap-2">
                  <Bot className="w-4 h-4 text-indigo-400" />
                  2. Run Phase 1 & 2 Main Initialization
                </h4>
                <p className="text-xs text-slate-400">
                  Initializes the default <code className="text-indigo-300">payment_bot.db</code> SQLite database file and verifies config parameters.
                </p>
                <div className="bg-slate-950 p-3 rounded-lg font-mono text-xs text-indigo-300 border border-slate-800 flex items-center justify-between">
                  <code>python3 main.py</code>
                  <button
                    onClick={() => copyToClipboard('python3 main.py', 'main_cmd')}
                    className="p-1 hover:bg-slate-800 rounded text-slate-400"
                  >
                    {copiedPath === 'main_cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Config Reference */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
              <h4 className="font-bold text-white text-sm flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-purple-400" />
                Myanmar Payment & Admin Environment Variables
              </h4>

              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 font-medium">
                    <tr>
                      <th className="p-3">Variable Key</th>
                      <th className="p-3">Example Value</th>
                      <th className="p-3">Purpose</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
                    <tr>
                      <td className="p-3 text-indigo-300 font-bold">BOT_TOKEN</td>
                      <td className="p-3 text-slate-400">7890123456:AAFx...</td>
                      <td className="p-3 text-slate-400">Telegram Bot API Token from @BotFather</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-indigo-300 font-bold">ADMIN_GROUP_ID</td>
                      <td className="p-3 text-slate-400">-1001987654321</td>
                      <td className="p-3 text-slate-400">Telegram Chat ID of Admin Review Group</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-indigo-300 font-bold">ADMIN_IDS</td>
                      <td className="p-3 text-slate-400">123456789,987654321</td>
                      <td className="p-3 text-slate-400">Comma-separated Telegram IDs of authorized admins</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-indigo-300 font-bold">KBZPAY_NO</td>
                      <td className="p-3 text-slate-400">09123456789</td>
                      <td className="p-3 text-slate-400">KBZPay phone number shown to users</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-indigo-300 font-bold">WAVEPAY_NO</td>
                      <td className="p-3 text-slate-400">09987654321</td>
                      <td className="p-3 text-slate-400">WavePay phone number shown to users</td>
                    </tr>
                    <tr>
                      <td className="p-3 text-indigo-300 font-bold">DB_PATH</td>
                      <td className="p-3 text-slate-400">payment_bot.db</td>
                      <td className="p-3 text-slate-400">Path to SQLite database file</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
