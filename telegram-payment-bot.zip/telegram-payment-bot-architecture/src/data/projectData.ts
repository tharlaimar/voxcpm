export interface FileItem {
  path: string;
  category: 'config' | 'database' | 'code' | 'docs';
  description: string;
  code: string;
}

export interface SchemaTable {
  name: string;
  description: string;
  columns: {
    name: string;
    type: string;
    constraints: string;
    description: string;
  }[];
}

export const PROJECT_FILES: FileItem[] = [
  {
    path: '.env.example',
    category: 'config',
    description: 'Environment variable configuration template with bot token, payment accounts, and admin IDs.',
    code: `# Telegram Bot Configuration
BOT_TOKEN=7890123456:AAFx_example_bot_token_here
ADMIN_GROUP_ID=-1001987654321
ADMIN_IDS=123456789,987654321

# Payment Details (Myanmar KBZPay & WavePay)
KBZPAY_NO=09123456789
KBZPAY_NAME=U Ba Maung
WAVEPAY_NO=09987654321
WAVEPAY_NAME=U Ba Maung

# SQLite Database Settings
DB_PATH=payment_bot.db`
  },
  {
    path: 'config.py',
    category: 'config',
    description: 'Python environment loader and dataclass configuration manager.',
    code: `import os
from typing import List
from dataclasses import dataclass, field

# Try loading .env file if python-dotenv is available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    if os.path.exists(".env"):
        with open(".env", "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    os.environ.setdefault(key.strip(), value.strip())


@dataclass
class Settings:
    """Configuration settings loaded from environment variables."""
    BOT_TOKEN: str = field(default_factory=lambda: os.getenv("BOT_TOKEN", "7890123456:AAFx_example_bot_token_here"))
    ADMIN_GROUP_ID: int = field(default_factory=lambda: int(os.getenv("ADMIN_GROUP_ID", "-1001987654321")))
    ADMIN_IDS_STR: str = field(default_factory=lambda: os.getenv("ADMIN_IDS", "123456789,987654321"))
    
    # Payment Accounts
    KBZPAY_NO: str = field(default_factory=lambda: os.getenv("KBZPAY_NO", "09123456789"))
    KBZPAY_NAME: str = field(default_factory=lambda: os.getenv("KBZPAY_NAME", "U Ba Maung"))
    WAVEPAY_NO: str = field(default_factory=lambda: os.getenv("WAVEPAY_NO", "09987654321"))
    WAVEPAY_NAME: str = field(default_factory=lambda: os.getenv("WAVEPAY_NAME", "U Ba Maung"))
    
    # Database
    DB_PATH: str = field(default_factory=lambda: os.getenv("DB_PATH", "payment_bot.db"))

    @property
    def admin_ids(self) -> List[int]:
        """Parse comma-separated admin IDs into a list of integers."""
        if not self.ADMIN_IDS_STR:
            return []
        try:
            return [int(x.strip()) for x in self.ADMIN_IDS_STR.split(",") if x.strip()]
        except ValueError:
            return []


settings = Settings()`
  },
  {
    path: 'database/schema.sql',
    category: 'database',
    description: 'Relational SQLite DDL schema defining users, subscriptions, payments, and active user subscriptions.',
    code: `-- SQLite Database Schema for Telegram Payment Bot

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    full_name TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Subscription Plans Table
CREATE TABLE IF NOT EXISTS subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price_mmk INTEGER NOT NULL,
    duration_days INTEGER NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT 1
);

-- 3. Payments Table
CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    payment_id TEXT UNIQUE NOT NULL,
    user_id INTEGER NOT NULL,
    plan_id INTEGER NOT NULL,
    payment_method TEXT NOT NULL, -- 'KBZPay' or 'WavePay'
    screenshot_file_id TEXT NOT NULL,
    admin_message_id INTEGER,
    status TEXT DEFAULT 'PENDING', -- 'PENDING', 'APPROVED', 'REJECTED'
    rejection_reason TEXT,
    reviewed_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (plan_id) REFERENCES subscriptions(id)
);

-- 4. User Active Subscriptions Table
CREATE TABLE IF NOT EXISTS user_subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    plan_id INTEGER NOT NULL,
    starts_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    status TEXT DEFAULT 'ACTIVE', -- 'ACTIVE', 'EXPIRED'
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (plan_id) REFERENCES subscriptions(id)
);

-- Indexes for query performance
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON payments(user_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON payments(status);
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_user_id ON user_subscriptions(user_id);`
  },
  {
    path: 'database/db.py',
    category: 'database',
    description: 'Async database manager executing CRUD queries with SQLite and automatic plan seeding.',
    code: `import os
import sqlite3
import asyncio
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

DB_PATH = os.getenv("DB_PATH", "payment_bot.db")


def _dict_factory(cursor: sqlite3.Cursor, row: tuple) -> Dict[str, Any]:
    """Convert SQLite row to dictionary."""
    return {col[0]: row[idx] for idx, col in enumerate(cursor.description)}


def _get_raw_connection(db_file: str = DB_PATH) -> sqlite3.Connection:
    """Get synchronous SQLite connection with Row dictionary factory."""
    conn = sqlite3.connect(db_file)
    conn.row_factory = _dict_factory
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def _sync_init_db(db_file: str = DB_PATH) -> None:
    """Synchronous DB schema initialization & default seed data insertion."""
    schema_path = os.path.join(os.path.dirname(__file__), "schema.sql")
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    
    if os.path.exists(schema_path):
        with open(schema_path, "r", encoding="utf-8") as f:
            schema_script = f.read()
        cursor.executescript(schema_script)

    # Seed default plans if table is empty
    cursor.execute("SELECT COUNT(*) as cnt FROM subscriptions")
    row = cursor.fetchone()
    if row and row['cnt'] == 0:
        default_plans = [
            ("1 Month VIP Access", 10000, 30, "Full VIP channel access for 30 days"),
            ("3 Months VIP Access", 25000, 90, "Save 5,000 MMK with 90 days access"),
            ("1 Year VIP Access", 80000, 365, "Best Value! 365 days unlimited access")
        ]
        cursor.executemany(
            "INSERT INTO subscriptions (name, price_mmk, duration_days, description) VALUES (?, ?, ?, ?)",
            default_plans
        )
        conn.commit()
    conn.close()


async def init_db(db_file: str = DB_PATH) -> None:
    """Async wrapper for initializing database schema."""
    await asyncio.to_thread(_sync_init_db, db_file)


# --- Database CRUD Operations ---

def _sync_add_or_update_user(user_id: int, username: Optional[str], full_name: str, db_file: str) -> None:
    conn = _get_raw_connection(db_file)
    conn.execute("""
        INSERT INTO users (user_id, username, full_name)
        VALUES (?, ?, ?)
        ON CONFLICT(user_id) DO UPDATE SET
            username = excluded.username,
            full_name = excluded.full_name;
    """, (user_id, username, full_name))
    conn.commit()
    conn.close()

async def add_or_update_user(user_id: int, username: Optional[str], full_name: str, db_file: str = DB_PATH) -> None:
    """Register or update user details upon /start command."""
    await asyncio.to_thread(_sync_add_or_update_user, user_id, username, full_name, db_file)


def _sync_get_subscription_plans(only_active: bool, db_file: str) -> List[Dict[str, Any]]:
    conn = _get_raw_connection(db_file)
    cursor = conn.cursor()
    query = "SELECT * FROM subscriptions" + (" WHERE is_active = 1" if only_active else "") + " ORDER BY duration_days ASC"
    cursor.execute(query)
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

async def get_subscription_plans(only_active: bool = True, db_file: str = DB_PATH) -> List[Dict[str, Any]]:
    """Retrieve available subscription plans."""
    return await asyncio.to_thread(_sync_get_subscription_plans, only_active, db_file)`
  },
  {
    path: 'requirements.txt',
    category: 'config',
    description: 'Python package requirements for aiogram 3.x, aiosqlite, and pydantic.',
    code: `aiogram>=3.17.0
aiosqlite>=0.20.0
pydantic>=2.10.0
pydantic-settings>=2.7.0
python-dotenv>=1.0.0`
  },
  {
    path: 'main.py',
    category: 'code',
    description: 'Application entry point verifying Phase 1 environment & Phase 2 SQLite initialization.',
    code: `import asyncio
import logging
from config import settings
from database.db import init_db, get_subscription_plans

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def setup_environment():
    """Phase 1: Verify environment variables."""
    logger.info("=== PHASE 1: PROJECT SETUP VERIFICATION ===")
    logger.info(f"DB Path        : {settings.DB_PATH}")
    logger.info(f"KBZPay No      : {settings.KBZPAY_NO} ({settings.KBZPAY_NAME})")
    logger.info(f"WavePay No     : {settings.WAVEPAY_NO} ({settings.WAVEPAY_NAME})")
    logger.info(f"Admin Group ID : {settings.ADMIN_GROUP_ID}")
    logger.info("✅ Phase 1 configuration loaded successfully.\n")


async def setup_database():
    """Phase 2: Initialize SQLite database schema and verify seeds."""
    logger.info("=== PHASE 2: DATABASE LAYER VERIFICATION ===")
    await init_db()
    plans = await get_subscription_plans()
    logger.info(f"Seeded Subscription Plans ({len(plans)}):")
    for plan in plans:
        logger.info(f"  • Plan #{plan['id']}: {plan['name']} - {plan['price_mmk']:,} MMK ({plan['duration_days']} Days)")
    logger.info("✅ Phase 2 SQLite database schema ready.\n")


async def main():
    logger.info("🚀 TELEGRAM PAYMENT BOT (PHASE 1 & 2 EXECUTABLE) 🚀")
    await setup_environment()
    await setup_database()


if __name__ == "__main__":
    asyncio.run(main())`
  },
  {
    path: 'test_database.py',
    category: 'code',
    description: 'Standalone automated integration test suite validating SQLite schema, seeding, user registration, and payment status transitions.',
    code: `import asyncio
import os
from database.db import (
    init_db,
    add_or_update_user,
    get_user,
    get_subscription_plans,
    create_payment,
    update_payment_status,
    grant_subscription,
    get_active_user_subscription
)

TEST_DB = "test_payment_bot.db"


async def run_tests():
    print("RUNNING AUTOMATED TEST SUITE FOR PHASE 1 & PHASE 2")
    if os.path.exists(TEST_DB):
        os.remove(TEST_DB)
        
    await init_db(TEST_DB)
    plans = await get_subscription_plans(db_file=TEST_DB)
    assert len(plans) == 3, "Failed plan seeding!"
    
    await add_or_update_user(99887766, "test_user", "Aung Aung", db_file=TEST_DB)
    user = await get_user(99887766, db_file=TEST_DB)
    assert user["full_name"] == "Aung Aung", "User registration failed!"
    
    payment = await create_payment("PAY-001", 99887766, 1, "KBZPay", "file_123", db_file=TEST_DB)
    assert payment["status"] == "PENDING"
    
    await update_payment_status("PAY-001", "APPROVED", reviewed_by=123, db_file=TEST_DB)
    await grant_subscription(99887766, 1, 30, db_file=TEST_DB)
    
    active_sub = await get_active_user_subscription(99887766, db_file=TEST_DB)
    assert active_sub is not None
    
    if os.path.exists(TEST_DB):
        os.remove(TEST_DB)
    print("ALL TESTS PASSED WITH 100% SUCCESS!")

if __name__ == "__main__":
    asyncio.run(run_tests())`
  },
  {
    path: 'states/payment.py',
    category: 'code',
    description: 'aiogram 3.x FSM StatesGroup managing payment plan selection, method choice, and screenshot upload states.',
    code: `from aiogram.fsm.state import State, StatesGroup

class PaymentState(StatesGroup):
    """FSM States for user subscription payment workflow."""
    selecting_plan = State()
    selecting_method = State()
    waiting_for_account = State()
    waiting_for_screenshot = State()`
  },
  {
    path: 'keyboards/inline.py',
    category: 'code',
    description: 'InlineKeyboardBuilder functions for generating subscription plans, KBZPay/WavePay selection, and cancel/contact buttons.',
    code: `from typing import List, Dict, Any
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

def get_plans_keyboard(plans: List[Dict[str, Any]]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for plan in plans:
        builder.button(text=f"⭐ {plan['name']} — {plan['price_mmk']:,} MMK", callback_data=f"select_plan:{plan['id']}")
    builder.button(text="💬 Contact Admin", callback_data="contact_admin")
    builder.adjust(1)
    return builder.as_markup()

def get_payment_methods_keyboard(plan_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔵 KBZPay", callback_data=f"method:KBZPay:{plan_id}")
    builder.button(text="🟡 WavePay", callback_data=f"method:WavePay:{plan_id}")
    builder.button(text="🔙 Back to Plans", callback_data="show_plans")
    builder.button(text="❌ Cancel Payment", callback_data="cancel_payment")
    builder.adjust(2, 1, 1)
    return builder.as_markup()

def get_cancel_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="❌ Cancel Payment", callback_data="cancel_payment")
    builder.button(text="💬 Contact Admin", callback_data="contact_admin")
    builder.adjust(1)
    return builder.as_markup()`
  },
  {
    path: 'handlers/user.py',
    category: 'code',
    description: 'aiogram 3.x user router handling /start, plan callbacks, payment account details, screenshot photo upload, duplicate payment prevention, and forwarding to admin group.',
    code: `import random
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from config import settings
from states.payment import PaymentState
from database.db import add_or_update_user, get_subscription_plans, get_plan_by_id, get_pending_payment_by_user, create_payment, set_admin_message_id
from keyboards.inline import get_plans_keyboard, get_payment_methods_keyboard, get_cancel_keyboard

user_router = Router(name="user_router")

@user_router.message(CommandStart())
async def command_start_handler(message: Message, state: FSMContext):
    await state.clear()
    await add_or_update_user(message.from_user.id, message.from_user.username, message.from_user.full_name)
    plans = await get_subscription_plans()
    await message.answer("👋 Welcome to the VIP Subscription Bot!", reply_markup=get_plans_keyboard(plans))

@user_router.message(PaymentState.waiting_for_screenshot, F.photo)
async def receive_payment_screenshot(message: Message, state: FSMContext):
    # Validates photo, checks pending status, generates payment ID, saves to SQLite & forwards to admin group
    pass`
  },
  {
    path: 'handlers/admin.py',
    category: 'code',
    description: 'aiogram 3.x admin router handling Approve & Reject inline callback queries, admin auth validation, status updates, subscription granting, user notifications, and message caption updates.',
    code: `import logging
from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery
from config import settings
from database.db import get_payment_by_id, update_payment_status, grant_subscription

admin_router = Router(name="admin_router")

@admin_router.callback_query(F.data.startswith("admin_approve:") | F.data.startswith("admin_reject:"))
async def process_admin_payment_review(callback: CallbackQuery, bot: Bot):
    if callback.from_user.id not in settings.admin_ids:
        await callback.answer("⚠️ Only authorized admins can review payments!", show_alert=True)
        return

    payment = await get_payment_by_id(payment_id)
    if payment["status"] != "PENDING":
        await callback.answer("This payment has already been processed.", show_alert=True)
        return

    if action == "admin_approve":
        await update_payment_status(payment_id, "APPROVED", admin_id)
        await grant_subscription(user_id, plan_id, duration_days)
        await bot.send_message(user_id, "✅ Payment Approved. Thank you for purchasing Studio99.")
        await callback.message.edit_caption(f"{caption}\\n\\n✅ Approved by {admin_tag}", reply_markup=None)`
  },
  {
    path: 'test_phase4.py',
    category: 'code',
    description: 'Automated unit test suite verifying Phase 4 admin review inline keyboards, authorization checks, approval/rejection flows, and database state updates.',
    code: `import unittest
from database.db import init_db, create_payment, update_payment_status, grant_subscription

class TestPhase4AdminWorkflow(unittest.IsolatedAsyncioTestCase):
    async def test_admin_approval_flow_and_subscription_grant(self):
        await init_db("test_phase4.db")
        payment = await create_payment("PAY-2026-8888", 55443322, 1, "KBZPay", "file_123", "test_phase4.db")
        updated = await update_payment_status("PAY-2026-8888", "APPROVED", 99887766, "test_phase4.db")
        self.assertEqual(updated["status"], "APPROVED")`
  }
];

export const SCHEMA_TABLES: SchemaTable[] = [
  {
    name: 'users',
    description: 'Stores Telegram user profiles registered automatically upon /start command.',
    columns: [
      { name: 'user_id', type: 'INTEGER', constraints: 'PRIMARY KEY', description: 'Unique Telegram User ID' },
      { name: 'username', type: 'TEXT', constraints: 'NULLABLE', description: 'Telegram handle (without @)' },
      { name: 'full_name', type: 'TEXT', constraints: 'NOT NULL', description: 'User display name on Telegram' },
      { name: 'created_at', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP', description: 'Account registration time' }
    ]
  },
  {
    name: 'subscriptions',
    description: 'Catalog of available subscription plans with Myanmar Kyat (MMK) pricing.',
    columns: [
      { name: 'id', type: 'INTEGER', constraints: 'PRIMARY KEY AUTOINCREMENT', description: 'Plan internal ID' },
      { name: 'name', type: 'TEXT', constraints: 'NOT NULL', description: 'Plan title (e.g., "1 Month VIP Access")' },
      { name: 'price_mmk', type: 'INTEGER', constraints: 'NOT NULL', description: 'Cost in Myanmar Kyat (e.g. 10000)' },
      { name: 'duration_days', type: 'INTEGER', constraints: 'NOT NULL', description: 'Access duration in days (e.g. 30, 90, 365)' },
      { name: 'description', type: 'TEXT', constraints: 'NULLABLE', description: 'Plan feature description' },
      { name: 'is_active', type: 'BOOLEAN', constraints: 'DEFAULT 1', description: 'Visibility flag for bot menu' }
    ]
  },
  {
    name: 'payments',
    description: 'Tracks user screenshot uploads, payment method chosen, and admin review decisions.',
    columns: [
      { name: 'id', type: 'INTEGER', constraints: 'PRIMARY KEY AUTOINCREMENT', description: 'Internal row ID' },
      { name: 'payment_id', type: 'TEXT', constraints: 'UNIQUE NOT NULL', description: 'Human-friendly ID (e.g. PAY-2026-1001)' },
      { name: 'user_id', type: 'INTEGER', constraints: 'FOREIGN KEY -> users', description: 'Telegram User ID who paid' },
      { name: 'plan_id', type: 'INTEGER', constraints: 'FOREIGN KEY -> subscriptions', description: 'Selected plan ID' },
      { name: 'payment_method', type: 'TEXT', constraints: 'NOT NULL', description: 'KBZPay or WavePay' },
      { name: 'screenshot_file_id', type: 'TEXT', constraints: 'NOT NULL', description: 'Telegram Photo file_id for review' },
      { name: 'admin_message_id', type: 'INTEGER', constraints: 'NULLABLE', description: 'Message ID in Admin Group for inline button edits' },
      { name: 'status', type: 'TEXT', constraints: "DEFAULT 'PENDING'", description: 'PENDING, APPROVED, REJECTED' },
      { name: 'rejection_reason', type: 'TEXT', constraints: 'NULLABLE', description: 'Optional reason if rejected by admin' },
      { name: 'reviewed_by', type: 'INTEGER', constraints: 'NULLABLE', description: 'Telegram User ID of reviewing admin' },
      { name: 'created_at', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP', description: 'Payment submission time' },
      { name: 'updated_at', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP', description: 'Review completion time' }
    ]
  },
  {
    name: 'user_subscriptions',
    description: 'Tracks active VIP access periods granted to users upon payment approval.',
    columns: [
      { name: 'id', type: 'INTEGER', constraints: 'PRIMARY KEY AUTOINCREMENT', description: 'Subscription record ID' },
      { name: 'user_id', type: 'INTEGER', constraints: 'FOREIGN KEY -> users', description: 'Subscribed user ID' },
      { name: 'plan_id', type: 'INTEGER', constraints: 'FOREIGN KEY -> subscriptions', description: 'Granted plan ID' },
      { name: 'starts_at', type: 'TIMESTAMP', constraints: 'DEFAULT CURRENT_TIMESTAMP', description: 'Access start timestamp' },
      { name: 'expires_at', type: 'TIMESTAMP', constraints: 'NOT NULL', description: 'VIP expiration date' },
      { name: 'status', type: 'TEXT', constraints: "DEFAULT 'ACTIVE'", description: 'ACTIVE or EXPIRED' }
    ]
  }
];

export const INITIAL_SEEDED_PLANS = [
  { id: 1, name: '10 Credits', price_mmk: 1000, product_type: 'credits', credit_amount: 10, duration_days: 0, description: 'Receive 10 AI Credits.' },
  { id: 2, name: '30 Credits', price_mmk: 3000, product_type: 'credits', credit_amount: 30, duration_days: 0, description: 'Receive 30 AI Credits.' },
  { id: 3, name: '50 Credits', price_mmk: 5000, product_type: 'credits', credit_amount: 50, duration_days: 0, description: 'Receive 50 AI Credits.' },
  { id: 4, name: 'Voice Clone VIP - 1 Day', price_mmk: 500, product_type: 'vip', credit_amount: 0, duration_days: 1, description: 'Unlimited Voice Clone access for 1 day.' },
  { id: 5, name: 'Voice Clone VIP - 7 Days', price_mmk: 2500, product_type: 'vip', credit_amount: 0, duration_days: 7, description: 'Unlimited Voice Clone access for 7 days.' },
  { id: 6, name: 'Voice Clone VIP - 30 Days', price_mmk: 10000, product_type: 'vip', credit_amount: 0, duration_days: 30, description: 'Unlimited Voice Clone access for 30 days.' }
];
