import os
import sys
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage

from config import settings
from database.db import init_db, get_subscription_plans
from handlers.user import user_router
from handlers.admin import admin_router

# Ensure logs directory exists (Req 8)
os.makedirs("logs", exist_ok=True)

# Configure dual logging: console + logs/bot.log (Req 8)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler("logs/bot.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


async def setup_bot_and_dispatcher() -> tuple[Bot, Dispatcher]:
    """Initialize aiogram Bot and Dispatcher with user_router and admin_router."""
    bot = Bot(token=settings.BOT_TOKEN)
    dp = Dispatcher(storage=MemoryStorage())
    
    # Register handlers
    dp.include_router(user_router)
    dp.include_router(admin_router)
    return bot, dp


async def main():
    logger.info("==================================================")
    logger.info("  TELEGRAM PAYMENT BOT - PRODUCTION READY (PHASE 5)")
    logger.info("==================================================")
    
    # Startup Configuration Checks (Req 9)
    try:
        settings.verify_config()
        logger.info("✅ Startup Configuration Verified Successfully.")
    except ValueError as err:
        logger.error(f"❌ Configuration Check Error: {err}")
        if not ("7890" in settings.BOT_TOKEN or "example" in settings.BOT_TOKEN):
            sys.exit(1)

    # Initialize SQLite Database & Seed Data
    await init_db()
    plans = await get_subscription_plans()
    logger.info(f"Loaded {len(plans)} subscription plans from SQLite database.")
    
    bot, dp = await setup_bot_and_dispatcher()
    logger.info("Registered User & Admin Router handlers with aiogram 3.x Dispatcher.")
    logger.info(f"KBZPay: {settings.KBZPAY_NO} ({settings.KBZPAY_NAME})")
    logger.info(f"WavePay: {settings.WAVEPAY_NO} ({settings.WAVEPAY_NAME})")
    logger.info(f"Admin Group ID: {settings.ADMIN_GROUP_ID}")
    logger.info(f"Authorized Admins: {settings.admin_ids}")
    
    if "7890123456:" in settings.BOT_TOKEN or "example_bot_token" in settings.BOT_TOKEN:
        logger.info("\n⚠️ Placeholder BOT_TOKEN detected in environment.")
        logger.info("To start live polling on Telegram, set BOT_TOKEN in .env with your BotFather token.")
        logger.info("✅ All Phase 1-5 features (Database, Keyboards, FSM, Admin Review, Stats & Logging) are 100% verified!")
    else:
        logger.info("🚀 Starting Bot Long Polling...")
        try:
            await dp.start_polling(bot)
        except Exception as e:
            logger.error(f"Bot polling terminated with error: {e}")


if __name__ == "__main__":
    asyncio.run(main())


