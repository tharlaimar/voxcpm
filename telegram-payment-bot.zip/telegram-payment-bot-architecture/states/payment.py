from aiogram.fsm.state import State, StatesGroup


class PaymentState(StatesGroup):
    """FSM States for user subscription payment workflow."""
    selecting_plan = State()
    selecting_method = State()
    waiting_for_account = State()
    waiting_for_screenshot = State()
