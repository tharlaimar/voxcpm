import os
import asyncio
import unittest
from datetime import datetime
from database.db import (
    init_db,
    add_or_update_user,
    get_subscription_plans,
    create_payment,
    get_payment_by_id,
    update_payment_status,
    grant_subscription,
    get_active_user_subscription
)
from keyboards.inline import (
    get_admin_review_keyboard,
    get_payment_details_keyboard
)


class TestPhase4AdminWorkflow(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self):
        self.test_db = "test_phase4.db"
        if os.path.exists(self.test_db):
            os.remove(self.test_db)
        await init_db(self.test_db)

    async def asyncTearDown(self):
        if os.path.exists(self.test_db):
            os.remove(self.test_db)

    async def test_admin_review_keyboard_generation(self):
        kb = get_admin_review_keyboard("PAY-2026-TEST")
        self.assertIsNotNone(kb)
        # 1 row, 2 buttons (Approve & Reject)
        self.assertEqual(len(kb.inline_keyboard[0]), 2)
        self.assertEqual(kb.inline_keyboard[0][0].callback_data, "admin_approve:PAY-2026-TEST")
        self.assertEqual(kb.inline_keyboard[0][1].callback_data, "admin_reject:PAY-2026-TEST")

    async def test_payment_details_keyboard_generation(self):
        kb = get_payment_details_keyboard("KBZPay", plan_id=1)
        self.assertIsNotNone(kb)
        button_texts = [btn.text for row in kb.inline_keyboard for btn in row]
        self.assertIn("📋 Copy Number", button_texts)
        self.assertIn("📤 Upload Screenshot", button_texts)
        self.assertIn("🔄 Change Payment Method", button_texts)
        if settings.SUPPORT_ADMIN_URL:
            self.assertIn("📞 Contact Admin", button_texts)
        self.assertIn("❌ Cancel", button_texts)

    async def test_admin_approval_flow_and_subscription_grant(self):
        user_id = 55443322
        admin_id = 99887766
        await add_or_update_user(user_id, "customer1", "Customer One", self.test_db)

        payment_id = "PAY-20260727-8888"
        created_pay = await create_payment(
            payment_id=payment_id,
            user_id=user_id,
            plan_id=1,
            payment_method="KBZPay",
            screenshot_file_id="AgACAg...fileid",
            db_file=self.test_db
        )
        self.assertEqual(created_pay["status"], "PENDING")

        # Fetch payment details
        payment = await get_payment_by_id(payment_id, self.test_db)
        self.assertIsNotNone(payment)
        self.assertEqual(payment["status"], "PENDING")

        # Approve Payment
        updated = await update_payment_status(
            payment_id=payment_id,
            status="APPROVED",
            reviewed_by=admin_id,
            db_file=self.test_db
        )
        self.assertEqual(updated["status"], "APPROVED")
        self.assertEqual(updated["reviewed_by"], admin_id)

        # Grant subscription
        sub = await grant_subscription(
            user_id=user_id,
            plan_id=1,
            duration_days=30,
            db_file=self.test_db
        )
        self.assertEqual(sub["status"], "ACTIVE")

        # Verify active subscription query
        active_sub = await get_active_user_subscription(user_id, self.test_db)
        self.assertIsNotNone(active_sub)
        self.assertEqual(active_sub["plan_id"], 1)

    async def test_admin_rejection_flow(self):
        user_id = 66554433
        admin_id = 99887766
        await add_or_update_user(user_id, "customer2", "Customer Two", self.test_db)

        payment_id = "PAY-20260727-7777"
        await create_payment(
            payment_id=payment_id,
            user_id=user_id,
            plan_id=2,
            payment_method="WavePay",
            screenshot_file_id="AgACAg...fileid2",
            db_file=self.test_db
        )

        # Reject Payment
        updated = await update_payment_status(
            payment_id=payment_id,
            status="REJECTED",
            reviewed_by=admin_id,
            rejection_reason="Invalid receipt screenshot",
            db_file=self.test_db
        )
        self.assertEqual(updated["status"], "REJECTED")
        self.assertEqual(updated["reviewed_by"], admin_id)

        # Confirm user gets no active subscription
        active_sub = await get_active_user_subscription(user_id, self.test_db)
        self.assertIsNone(active_sub)


if __name__ == "__main__":
    unittest.main()
