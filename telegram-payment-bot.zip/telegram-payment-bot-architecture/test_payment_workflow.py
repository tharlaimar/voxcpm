import asyncio
import os
import sqlite3
from database.db import (
    init_db,
    add_or_update_user,
    get_plan_by_id,
    create_payment,
    get_payment_by_id,
    DB_PATH
)

async def test_workflow():
    print("=" * 65)
    print("  RUNNING STUDIO99 PRODUCT WORKFLOW TEST SUITE")
    print("=" * 65)

    # Initialize DB
    await init_db("test_workflow.db")
    
    # 1. Add User
    user_id = 11223344
    await add_or_update_user(user_id, "test_user", "Test User", db_file="test_workflow.db")
    print("\n[TEST 1] User Registration")
    print("  -> PASS: Registered User 'Test User'")

    # 2. Test AI Credits Product Payment Creation (with Studio99 Email/ID)
    credit_plan = await get_plan_by_id(1, db_file="test_workflow.db")
    assert credit_plan["product_type"] == "credits"

    pay_credits = await create_payment(
        payment_id="PAY-TEST-CREDITS-01",
        user_id=user_id,
        plan_id=1,
        payment_method="KBZPay",
        screenshot_file_id="FILE_CREDITS_123",
        studio99_account="user@studio99.ai",
        db_file="test_workflow.db"
    )
    print("\n[TEST 2] AI Credits Payment Creation with Studio99 Account")
    print(f"  -> PASS: Created Payment ID '{pay_credits['payment_id']}' with Account '{pay_credits.get('studio99_account')}'")
    assert pay_credits.get("studio99_account") == "user@studio99.ai"

    # 3. Test Voice Clone VIP Payment Creation (without Studio99 Account)
    vip_plan = await get_plan_by_id(4, db_file="test_workflow.db")
    assert vip_plan["product_type"] == "vip"

    pay_vip = await create_payment(
        payment_id="PAY-TEST-VIP-01",
        user_id=user_id,
        plan_id=4,
        payment_method="WavePay",
        screenshot_file_id="FILE_VIP_456",
        studio99_account=None,
        db_file="test_workflow.db"
    )
    print("\n[TEST 3] Voice Clone VIP Payment Creation without Studio99 Account")
    print(f"  -> PASS: Created Payment ID '{pay_vip['payment_id']}' with Account '{pay_vip.get('studio99_account')}'")
    assert pay_vip.get("studio99_account") is None

    # 4. Fetch payments and verify details
    fetched_credits = await get_payment_by_id("PAY-TEST-CREDITS-01", db_file="test_workflow.db")
    assert fetched_credits["studio99_account"] == "user@studio99.ai"
    assert fetched_credits["product_type"] == "credits"

    fetched_vip = await get_payment_by_id("PAY-TEST-VIP-01", db_file="test_workflow.db")
    assert fetched_vip["studio99_account"] is None
    assert fetched_vip["product_type"] == "vip"

    print("\n[TEST 4] Database Retrieval Verification")
    print("  -> PASS: Verified AI Credits and VIP payment record fields.")

    print("\n" + "=" * 65)
    print("  ALL WORKFLOW TESTS PASSED SUCCESSFULLY! 🚀")
    print("=" * 65)

    if os.path.exists("test_workflow.db"):
        os.remove("test_workflow.db")

if __name__ == "__main__":
    asyncio.run(test_workflow())
